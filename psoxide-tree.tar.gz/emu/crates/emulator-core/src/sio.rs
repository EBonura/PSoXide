//! SIO0 -- controller / memory-card serial port.
//!
//! Register map at `0x1F80_1040`:
//!   +0  `SIO0_DATA`  TX/RX FIFO (8-bit; reads may be accessed as wider)
//!   +4  `SIO0_STAT`  status (32-bit, read-only)
//!   +8  `SIO0_MODE`  framing config (16-bit)
//!   +A  `SIO0_CTRL`  control (16-bit)
//!   +E  `SIO0_BAUD`  baud divisor (16-bit)
//!
//! The core default has a digital controller and memory card on port 1,
//! plus a memory card on port 2. Frontend launches replace the card
//! backing with the per-game save file, while parity probes use the
//! same fresh-card default as Redux's portable profile.
//!
//! ## Provenance
//!
//! Portions of this module are parity-matched against, and in places
//! derived from, PCSX-Redux (<https://github.com/grumpycoders/pcsx-redux>),
//! Copyright (C) the PCSX-Redux authors, GPL-2.0-or-later. Points of
//! correspondence are flagged inline with `Redux` references. PSoXide is
//! released under GPL-2.0-or-later in part to honor this lineage; see
//! `LICENSE` and `docs/license-audit.md`.

mod stat_bit {
    // Layout facts come from the shared hardware-model crate, the same
    // source psx-pad and psx-mc consume, so the third hand-copied set of
    // these bits is gone. Local names kept for the emulator's call sites.
    use psx_hw::sio::sio0;
    pub const TX_READY_1: u32 = sio0::stat::TX_READY;
    pub const RX_NOT_EMPTY: u32 = sio0::stat::RX_NOT_EMPTY;
    pub const TX_READY_2: u32 = sio0::stat::TX_IDLE;
    /// ACK/DSR input level from the selected device.
    pub const ACK_INPUT: u32 = sio0::stat::DSR_LEVEL;
    /// SIO0 interrupt latched in the controller's own STAT register.
    pub const IRQ: u32 = sio0::stat::IRQ;
}

mod ctrl_bit {
    use psx_hw::sio::sio0;
    /// bit 1 -- drive `/JOYN` output. Transitioning high-to-low is how
    /// the CPU "selects" the device at the start of a transfer; going
    /// low-to-high deselects and resets the device state machine.
    pub const JOYN_OUTPUT: u16 = sio0::ctrl::DTR;
    /// SIO0-only one-shot receive override. Normal selected-port traffic keeps
    /// this clear; hardware automatically clears it after one received byte.
    pub const FORCE_RX_ONCE: u16 = sio0::ctrl::FORCE_RX_ONCE;
    /// Write-1 to acknowledge pending IRQ bits in STAT.
    pub const ACK: u16 = sio0::ctrl::ACK;
    /// Write-1 to soft-reset the port.
    pub const RESET: u16 = sio0::ctrl::RESET;
    /// bit 12 -- enable IRQ7 generation from controller ACK pulses.
    pub const ACK_IRQ_ENABLE: u16 = sio0::ctrl::ACK_IRQ_EN;
    /// bit 13 -- port / slot select (0 = JOY1, 1 = JOY2).
    pub const SLOT: u16 = sio0::ctrl::SLOT_PORT2;
}

mod offset {
    pub const DATA: u32 = 0x0;
    pub const STAT: u32 = 0x4;
    /// High half of the 32-bit STAT register; 16-bit reads land here
    /// when software does two half-reads. Returns zero on hardware.
    pub const STAT_HI: u32 = 0x6;
    pub const MODE: u32 = 0x8;
    pub const CTRL: u32 = 0xA;
    pub const BAUD: u32 = 0xE;
}

/// SIO0 MODE exposes only its framing/baud configuration bits. Reserved bits
/// read back zero; this is visible even when software uses byte stores because
/// the R3000A still drives the complete source register on the peripheral bus.
const MODE_WRITE_MASK: u16 = 0x013F;

/// Serial-transfer time for one byte when BAUD is zero. Matches the
/// BIOS's common `0x88 * 8 = 1088`-cycle setup.
const DEFAULT_TRANSFER_TICKS: u64 = 1088;
/// Legacy pad ACK pulse width. The data byte itself is made available
/// synchronously like Redux; the delayed event represents the IRQ/ACK
/// edge, not byte delivery.
const PAD_ACK_DELAY_TICKS: u64 = 0;
/// Memory cards share the same SIO baud-clocked IRQ timing in Redux.
const MEMCARD_ACK_DELAY_TICKS: u64 = 0;
/// `/ACK` is a pulse, not a sticky level.
const ACK_PULSE_TICKS: u64 = 100;

/// SIO0 state. Register-level accuracy for the "nothing plugged in"
/// path; no shift-clock simulation, but every byte-write pulses an
/// IRQ7 so the BIOS's pad-poll handler advances its descriptors.
#[derive(serde::Serialize, serde::Deserialize)]
pub struct Sio0 {
    mode: u16,
    ctrl: u16,
    baud: u16,
    /// One-slot RX buffer. The real chip has a small FIFO; the BIOS
    /// only reads one response per TX so a single slot is enough.
    /// `None` means RX empty (`STAT.RX_NOT_EMPTY` clears).
    rx: Option<u8>,
    /// Set by `write_data`, consumed by [`Sio0::take_pending_irq`].
    /// The Bus raises `IrqSource::Controller` when true. Mirrors how
    /// real hardware pulses IRQ7 when `/DSR` ACKs a transfer (or
    /// DSR-timeout fires if nothing answers).
    pending_irq: bool,
    /// Sticky ACK input level exposed in `STAT` bit 7. Cleared when a
    /// new transfer starts, on deselect, or on reset.
    ack_input: bool,
    /// Sticky SIO IRQ bit exposed in `STAT` bit 9. Writing CTRL.ACK
    /// clears it; the bus-level interrupt controller is separate.
    irq_latched: bool,
    /// Last byte produced by the selected device. Redux makes the
    /// byte visible in DATA immediately; this copy is retained for the
    /// older transfer-deadline scaffolding and diagnostics.
    pending_rx: u8,
    /// Legacy one-byte TX holding register. The Redux-aligned path
    /// currently accepts DATA writes synchronously, so this remains
    /// empty unless the older deadline path is re-enabled.
    queued_tx: Option<u8>,
    /// Whether the current byte will be followed by a delayed SIO
    /// event.
    pending_ack: bool,
    /// Whether the current byte should raise an IRQ without a visible
    /// ACK pulse. Kept for the legacy delayed-byte path; Redux-style
    /// missing devices leave this false.
    pending_dsr_timeout: bool,
    /// Legacy shifter state for the older delayed-byte path.
    transfer_busy: bool,
    /// Legacy wait state for the older delayed-byte path.
    awaiting_ack: bool,
    /// Absolute cycle at which the current byte transfer completes.
    transfer_deadline: Option<u64>,
    /// Absolute cycle at which the pending ACK pulse should fire.
    ack_deadline: Option<u64>,
    /// Absolute cycle at which the ACK pulse ends.
    ack_end_deadline: Option<u64>,
    /// Delay for the currently selected device kind.
    ack_delay_ticks: u64,
    /// Device on port 1 (controller slot 1 + memory card 1).
    port1: crate::pad::PortDevice,
    /// Device on port 2 (controller slot 2 + memory card 2).
    port2: crate::pad::PortDevice,
    /// Last observed JOYN-output level. We use high-to-low
    /// transitions (deselect → select) to reset device state
    /// machines, matching hardware.
    last_joyn: bool,
    /// Opt-in: model a slow original controller (e.g. SCPH-1200) that only
    /// becomes ready for the next byte once it has pulsed `/ACK`. A host that
    /// clocks the next byte without waiting for that pulse desyncs the packet.
    /// Off by default; the idealized fast pad above is what normal runs use.
    slow_pad: bool,
    /// While `slow_pad`: the cycle the device is ready for the next byte (the
    /// current byte's `/ACK` deadline). `None` between transactions.
    slow_ready_cycle: Option<u64>,
    /// While `slow_pad`: set once a byte was clocked before the device was
    /// ready; the rest of the packet then returns `0xFF` until deselect.
    slow_desynced: bool,
}

impl Sio0 {
    /// Physical base address of SIO0.
    pub const BASE: u32 = 0x1F80_1040;
    /// Size of the register window (`DATA..=BAUD` plus padding).
    pub const SIZE: u32 = 0x10;

    /// All registers zero, port 1 pre-populated with a digital pad and
    /// a fresh memory card, port 2 with a fresh memory card. The
    /// frontend replaces port 1's card backing on game launch; keeping
    /// a default card here matches Redux's portable startup profile
    /// and lets BIOS/game card probes observe an inserted card.
    pub fn new() -> Self {
        Self {
            mode: 0,
            ctrl: 0,
            baud: 0,
            rx: None,
            pending_irq: false,
            ack_input: false,
            irq_latched: false,
            pending_rx: 0xFF,
            queued_tx: None,
            pending_ack: false,
            pending_dsr_timeout: false,
            transfer_busy: false,
            awaiting_ack: false,
            transfer_deadline: None,
            ack_deadline: None,
            ack_end_deadline: None,
            ack_delay_ticks: PAD_ACK_DELAY_TICKS,
            port1: crate::pad::PortDevice::empty()
                .with_pad(crate::pad::DigitalPad::new())
                .with_memcard(crate::pad::MemoryCard::new()),
            port2: crate::pad::PortDevice::empty().with_memcard(crate::pad::MemoryCard::new()),
            last_joyn: false,
            slow_pad: false,
            slow_ready_cycle: None,
            slow_desynced: false,
        }
    }

    /// Enable or disable the slow original-controller timing model. When on, a
    /// poll that does not wait for each byte's `/ACK` pulse desyncs, reproducing
    /// an SCPH-1200 against a host that clocks bytes back-to-back. Used by the
    /// regression tests below.
    pub fn set_slow_pad(&mut self, slow: bool) {
        self.slow_pad = slow;
        if !slow {
            self.slow_ready_cycle = None;
            self.slow_desynced = false;
        }
    }

    /// Immutable access to port 1. Used by the frontend to read
    /// pad state (rumble motor) without having to mutate.
    pub fn port1(&self) -> &crate::pad::PortDevice {
        &self.port1
    }

    /// Mutable access to port 1 -- lets higher layers swap a
    /// memory card in while keeping the pad attached.
    pub fn port1_mut(&mut self) -> &mut crate::pad::PortDevice {
        &mut self.port1
    }

    /// Immutable access to port 2.
    pub fn port2(&self) -> &crate::pad::PortDevice {
        &self.port2
    }

    /// Mutable access to port 2.
    pub fn port2_mut(&mut self) -> &mut crate::pad::PortDevice {
        &mut self.port2
    }

    /// Plug a device into port 1 (typical for "player 1" games).
    pub fn attach_port1(&mut self, device: crate::pad::PortDevice) {
        self.port1 = device;
    }

    /// Plug a device into port 2.
    pub fn attach_port2(&mut self, device: crate::pad::PortDevice) {
        self.port2 = device;
    }

    /// Update the button state held on port 1.
    pub fn set_port1_buttons(&mut self, buttons: crate::pad::ButtonState) {
        self.port1.set_buttons(buttons);
    }

    /// Update the button state held on port 2.
    pub fn set_port2_buttons(&mut self, buttons: crate::pad::ButtonState) {
        self.port2.set_buttons(buttons);
    }

    /// Returns true and clears the flag when a DATA write has armed
    /// IRQ7. The Bus calls this after dispatching a write.
    pub fn take_pending_irq(&mut self) -> bool {
        let p = self.pending_irq;
        self.pending_irq = false;
        p
    }

    /// Snapshot the software-visible STAT register without consuming
    /// any FIFO state. Diagnostic-only.
    pub fn debug_stat(&self) -> u32 {
        self.stat()
    }

    /// Diagnostic-only copy of the raw CTRL register.
    pub fn debug_ctrl(&self) -> u16 {
        self.ctrl
    }

    /// Whether `service_sio0` would currently raise a controller IRQ
    /// edge to the bus.
    pub fn debug_pending_irq(&self) -> bool {
        self.pending_irq
    }

    /// Sticky IRQ bit exposed in `STAT`.
    pub fn debug_irq_latched(&self) -> bool {
        self.irq_latched
    }

    /// Whether a TX byte is currently shifting.
    pub fn debug_transfer_busy(&self) -> bool {
        self.transfer_busy
    }

    /// Whether the transfer phase finished and the ACK delay is in
    /// flight.
    pub fn debug_awaiting_ack(&self) -> bool {
        self.awaiting_ack
    }

    /// Absolute cycle where the current byte transfer completes.
    pub fn debug_transfer_deadline(&self) -> Option<u64> {
        self.transfer_deadline
    }

    /// Absolute cycle where the next ACK pulse should begin.
    pub fn debug_ack_deadline(&self) -> Option<u64> {
        self.ack_deadline
    }

    /// Absolute cycle where the current ACK pulse ends.
    pub fn debug_ack_end_deadline(&self) -> Option<u64> {
        self.ack_end_deadline
    }

    /// Earliest pending state-machine deadline across the three
    /// timers, or `None` if SIO0 is idle. The bus uses this to
    /// (re)schedule [`EventSlot::Sio`] so the per-instruction
    /// `Bus::tick` poll can be retired in favour of one event-driven
    /// wake-up. Mirrors the role of `intCycle[PSXINT_SIO]` in
    /// PCSX-Redux's `branchTest`.
    pub fn next_deadline(&self) -> Option<u64> {
        let mut next: Option<u64> = None;
        let consider = |cur: &mut Option<u64>, candidate: Option<u64>| {
            if let Some(c) = candidate {
                *cur = Some(match cur {
                    Some(prev) => (*prev).min(c),
                    None => c,
                });
            }
        };
        consider(&mut next, self.transfer_deadline);
        consider(&mut next, self.ack_deadline);
        consider(&mut next, self.ack_end_deadline);
        next
    }

    /// RX slot contents, if a byte is waiting to be read.
    pub fn debug_rx(&self) -> Option<u8> {
        self.rx
    }

    /// Next TX byte queued behind the active transfer.
    pub fn debug_queued_tx(&self) -> Option<u8> {
        self.queued_tx
    }

    /// `true` when `phys` falls within the SIO0 register window.
    #[inline]
    pub fn contains(phys: u32) -> bool {
        (Self::BASE..Self::BASE + Self::SIZE).contains(&phys)
    }

    /// `SIO0_STAT`. Redux completes byte exchange synchronously; the
    /// baud-clocked delay is for the later SIO IRQ event, not DATA
    /// visibility.
    fn stat(&self) -> u32 {
        let mut s = 0;
        if self.queued_tx.is_none() {
            s |= stat_bit::TX_READY_1;
        }
        if !self.transfer_busy && !self.awaiting_ack {
            s |= stat_bit::TX_READY_2;
        }
        if self.rx.is_some() {
            s |= stat_bit::RX_NOT_EMPTY;
        }
        if self.ack_input {
            s |= stat_bit::ACK_INPUT;
        }
        if self.irq_latched {
            s |= stat_bit::IRQ;
        }
        s
    }

    /// Pop the RX slot, returning 0xFF when empty. Used by all three
    /// widths of DATA read -- the real chip zero-extends on the bus.
    fn pop_rx(&mut self) -> u8 {
        self.rx.take().unwrap_or(0xFF)
    }

    /// Transfer time for one byte. Hardware uses `BAUD * 8`; when the
    /// BIOS hasn't set BAUD yet we still give software a realistic
    /// default delay instead of "instant byte".
    fn transfer_ticks(&self) -> u64 {
        let baud = self.baud as u64;
        if baud != 0 {
            baud.saturating_mul(8)
        } else {
            DEFAULT_TRANSFER_TICKS
        }
    }

    /// Advance any pending transfer / ACK timers to `now`.
    pub fn tick(&mut self, now: u64) {
        loop {
            if let Some(deadline) = self.transfer_deadline {
                if deadline <= now {
                    self.transfer_deadline = None;
                    self.rx = Some(self.pending_rx);
                    self.transfer_busy = false;
                    if self.pending_ack {
                        self.awaiting_ack = true;
                        self.ack_deadline = Some(deadline.saturating_add(self.ack_delay_ticks));
                    }
                    if let Some(value) = self.queued_tx.take() {
                        self.start_transfer_at(value, deadline, false);
                    } else if !self.awaiting_ack {
                        self.transfer_busy = false;
                    }
                    continue;
                }
            }

            if let Some(deadline) = self.ack_deadline {
                if deadline <= now {
                    self.ack_deadline = None;
                    self.awaiting_ack = false;
                    let ack_pulse = self.pending_ack;
                    let dsr_timeout = self.pending_dsr_timeout;
                    self.pending_ack = false;
                    self.pending_dsr_timeout = false;
                    if ack_pulse {
                        // Keep IRQ and visible ACK/DSR in phase. Crash's
                        // BIOS pad handler samples the ACK level while it
                        // services the interrupt; raising IRQ at RX-ready
                        // time makes digital polls stop before the high
                        // button byte.
                        self.ack_input = true;
                        self.ack_end_deadline = Some(deadline.saturating_add(ACK_PULSE_TICKS));
                    }
                    if (ack_pulse || dsr_timeout)
                        && self.ctrl & ctrl_bit::ACK_IRQ_ENABLE != 0
                        && !self.irq_latched
                    {
                        self.irq_latched = true;
                        self.pending_irq = true;
                    }
                    continue;
                }
            }

            if let Some(deadline) = self.ack_end_deadline {
                if deadline <= now {
                    self.ack_end_deadline = None;
                    self.ack_input = false;
                    continue;
                }
            }

            break;
        }
    }

    /// 32-bit read dispatch. `Some(value)` for every offset in the
    /// window; unrecognised offsets read as zero to match the general
    /// MMIO echo-buffer fallback. Reading `DATA` consumes the RX slot.
    pub fn read32(&mut self, phys: u32) -> Option<u32> {
        match phys - Self::BASE {
            offset::DATA => Some(self.pop_rx() as u32),
            offset::STAT => Some(self.stat()),
            offset::MODE => Some(self.mode as u32),
            offset::CTRL => Some(self.ctrl as u32),
            offset::BAUD => Some(self.baud as u32),
            _ => Some(0),
        }
    }

    /// 16-bit read dispatch.
    pub fn read16(&mut self, phys: u32) -> Option<u16> {
        match phys - Self::BASE {
            offset::DATA => Some(self.pop_rx() as u16),
            offset::STAT => Some(self.stat() as u16),
            offset::STAT_HI => Some(0),
            offset::MODE => Some(self.mode),
            offset::CTRL => Some(self.ctrl),
            offset::BAUD => Some(self.baud),
            _ => Some(0),
        }
    }

    /// 8-bit read dispatch.
    pub fn read8(&mut self, phys: u32) -> Option<u8> {
        match phys - Self::BASE {
            offset::DATA => Some(self.pop_rx()),
            offset::STAT => Some(self.stat() as u8),
            offset::MODE => Some(self.mode as u8),
            offset::CTRL => Some(self.ctrl as u8),
            offset::BAUD => Some(self.baud as u8),
            _ => Some(0),
        }
    }

    /// TX clocks one byte across the active port's serial link. The
    /// selected device (if any) returns its RX byte and whether it
    /// wants another round (pulls `/DSR` low → IRQ7 armed).
    fn write_data_at(&mut self, value: u8, now: u64) {
        self.start_transfer_at(value, now, true);
    }

    fn start_transfer_at(&mut self, value: u8, now: u64, clear_ack_pulse: bool) {
        // A fresh byte clocks a new phase of the transfer, so the
        // previous ACK pulse is no longer visible.
        if clear_ack_pulse {
            self.ack_input = false;
            self.ack_end_deadline = None;
        }
        let selected = self.ctrl & ctrl_bit::JOYN_OUTPUT != 0;
        let force_rx_once = self.ctrl & ctrl_bit::FORCE_RX_ONCE != 0;
        let receive_enabled = selected || force_rx_once;
        let (rx, ack, _device_present, ack_delay_ticks) = if selected {
            // Slow original-controller timing: a byte clocked before the
            // previous byte's `/ACK` deadline arrives while the device is still
            // busy, so it misses the clock and the rest of the packet desyncs.
            if self.slow_pad {
                if self.slow_ready_cycle.is_some_and(|ready| now < ready) {
                    self.slow_desynced = true;
                }
                self.slow_ready_cycle = Some(now.saturating_add(self.transfer_ticks()));
            }
            if self.slow_pad && self.slow_desynced {
                // The device missed the clock; it returns idle and does not
                // advance its state machine.
                (0xFF, false, true, PAD_ACK_DELAY_TICKS)
            } else {
                let port = self.active_port();
                let result = port.exchange_detailed_at(value, now);
                let ack_delay_ticks = if port.selected_is_memcard() {
                    MEMCARD_ACK_DELAY_TICKS
                } else {
                    PAD_ACK_DELAY_TICKS
                };
                (
                    result.rx,
                    result.ack,
                    result.device_present,
                    ack_delay_ticks,
                )
            }
        } else {
            (0xFF, false, true, PAD_ACK_DELAY_TICKS)
        };
        // Redux returns 0xff for a missing device but does not schedule
        // an ACK/DSR IRQ for that byte. RE2 polls port 2 during the BIOS
        // pad handler; raising a timeout IRQ there invents extra IRQ7
        // passes inside the same folded ISR.
        let dsr_timeout = false;
        self.pending_rx = rx;
        self.pending_ack = ack;
        self.pending_dsr_timeout = dsr_timeout;
        self.ack_delay_ticks = ack_delay_ticks;
        self.rx = receive_enabled.then_some(rx);
        if receive_enabled {
            // SIO0 CTRL.2 is a force-receive strobe, not a persistent RX
            // enable. Retail hardware clears it after exactly one byte.
            self.ctrl &= !ctrl_bit::FORCE_RX_ONCE;
        }
        self.transfer_busy = false;
        self.awaiting_ack = false;
        self.transfer_deadline = None;
        self.ack_deadline = if ack || dsr_timeout {
            Some(
                now.saturating_add(self.transfer_ticks())
                    .saturating_add(if ack { ack_delay_ticks } else { 0 }),
            )
        } else {
            None
        };
    }

    /// Device selected by the current `CTRL.SLOT` bit.
    fn active_port(&mut self) -> &mut crate::pad::PortDevice {
        if self.ctrl & ctrl_bit::SLOT == 0 {
            &mut self.port1
        } else {
            &mut self.port2
        }
    }

    fn write_ctrl(&mut self, value: u16) {
        if value & ctrl_bit::RESET != 0 {
            self.mode = 0;
            self.ctrl = 0;
            self.baud = 0;
            self.pending_irq = false;
            self.ack_input = false;
            self.irq_latched = false;
            self.pending_rx = 0xFF;
            self.queued_tx = None;
            self.pending_ack = false;
            self.pending_dsr_timeout = false;
            self.transfer_busy = false;
            self.awaiting_ack = false;
            self.transfer_deadline = None;
            self.ack_deadline = None;
            self.ack_end_deadline = None;
            self.rx = None;
            self.port1.deselect();
            self.port2.deselect();
            self.last_joyn = false;
            // Keep the slow-pad opt-in, drop its per-transaction state.
            self.slow_ready_cycle = None;
            self.slow_desynced = false;
            return;
        }
        if value & ctrl_bit::ACK != 0 {
            self.irq_latched = false;
            self.pending_irq = false;
        }
        // ACK bit is write-1-to-clear of STAT.IRQ9; don't keep it in
        // the stored register value.
        let new_ctrl = value & !ctrl_bit::ACK;
        // Edge-detect JOYN: the high-to-low transition starts a new
        // transfer; the low-to-high transition deselects and the
        // device state machine resets.
        let old_joyn = self.last_joyn;
        let new_joyn = new_ctrl & ctrl_bit::JOYN_OUTPUT != 0;
        if old_joyn && !new_joyn {
            self.ack_input = false;
            self.queued_tx = None;
            self.pending_ack = false;
            self.pending_dsr_timeout = false;
            self.transfer_busy = false;
            self.awaiting_ack = false;
            self.transfer_deadline = None;
            self.ack_deadline = None;
            self.ack_end_deadline = None;
            self.port1.deselect();
            self.port2.deselect();
            // A fresh select starts a clean packet for the slow-pad model.
            self.slow_ready_cycle = None;
            self.slow_desynced = false;
        }
        self.last_joyn = new_joyn;
        self.ctrl = new_ctrl;
    }

    /// 32-bit write dispatch. STAT is 32-bit on hardware but the
    /// writable registers all live in the 16-bit half, so we delegate.
    pub fn write32(&mut self, phys: u32, value: u32) -> bool {
        self.write16_at(phys, value as u16, 0)
    }

    /// 16-bit write dispatch. Returns `true` when the address fell in
    /// a recognised slot (even if the write was semantically ignored).
    pub fn write16(&mut self, phys: u32, value: u16) -> bool {
        self.write16_at(phys, value, 0)
    }

    /// Cycle-aware 32-bit write dispatch.
    pub fn write32_at(&mut self, phys: u32, value: u32, now: u64) -> bool {
        self.write16_at(phys, value as u16, now)
    }

    /// Cycle-aware 16-bit write dispatch.
    pub fn write16_at(&mut self, phys: u32, value: u16, now: u64) -> bool {
        match phys - Self::BASE {
            offset::DATA => self.write_data_at(value as u8, now),
            offset::STAT => {}
            offset::MODE => self.mode = value & MODE_WRITE_MASK,
            offset::CTRL => self.write_ctrl(value),
            offset::BAUD => self.baud = value,
            _ => return false,
        }
        true
    }

    /// 8-bit write dispatch. Only `DATA` accepts a byte write; every
    /// other register is 16-bit on the real chip.
    pub fn write8(&mut self, phys: u32, value: u8) -> bool {
        self.write8_at(phys, value, 0)
    }

    /// Cycle-aware 8-bit write dispatch.
    pub fn write8_at(&mut self, phys: u32, value: u8, now: u64) -> bool {
        match phys - Self::BASE {
            offset::DATA => self.write_data_at(value, now),
            _ => return false,
        }
        true
    }
}

impl Default for Sio0 {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn stat_reports_tx_ready_bits() {
        let mut sio = Sio0::new();
        let s = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_eq!(s & 0x1, 0x1, "TX_READY_1 must be set");
        assert_eq!(s & 0x4, 0x4, "TX_READY_2 must be set");
        assert_eq!(s & 0x2, 0, "RX_NOT_EMPTY must be clear");
    }

    #[test]
    fn data_read_returns_ff_no_device() {
        // Unseat the default pad so we can verify the no-device path
        // stays correct (TX ignored, DATA reads 0xFF).
        let mut sio = Sio0::new();
        sio.attach_port1(crate::pad::PortDevice::empty());
        assert_eq!(sio.read8(Sio0::BASE).unwrap(), 0xFF);
        assert_eq!(sio.read16(Sio0::BASE).unwrap(), 0x00FF);
    }

    #[test]
    fn stat_hi_half_reads_zero() {
        let mut sio = Sio0::new();
        assert_eq!(sio.read16(Sio0::BASE + 0x6).unwrap(), 0);
    }

    #[test]
    fn tx_fills_rx_with_ff_and_sets_stat_bit() {
        // With /CS high, CTRL.2 force-arms exactly one received byte.
        let mut sio = Sio0::new();
        sio.attach_port1(crate::pad::PortDevice::empty());
        sio.write16(Sio0::BASE + 0xA, ctrl_bit::FORCE_RX_ONCE);
        sio.write8(Sio0::BASE, 0x01);
        sio.tick(DEFAULT_TRANSFER_TICKS);
        let s = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_eq!(s & 0x2, 0x2, "RX_NOT_EMPTY must be set after TX");
        assert_eq!(sio.read8(Sio0::BASE).unwrap(), 0xFF);
        // Reading DATA consumes the RX slot.
        let s = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_eq!(s & 0x2, 0, "RX_NOT_EMPTY must be clear after DATA read");
    }

    #[test]
    fn force_rx_is_one_shot_and_selected_receive_does_not_need_it() {
        let mut sio = Sio0::new();
        sio.attach_port1(crate::pad::PortDevice::empty());

        sio.write16(Sio0::BASE + 0xA, ctrl_bit::FORCE_RX_ONCE);
        sio.write8(Sio0::BASE, 0x00);
        assert_eq!(sio.read8(Sio0::BASE).unwrap(), 0xFF);
        assert_eq!(
            sio.debug_ctrl() & ctrl_bit::FORCE_RX_ONCE,
            0,
            "hardware clears CTRL.2 after one received byte"
        );

        sio.write8(Sio0::BASE, 0x00);
        assert_eq!(
            sio.read32(Sio0::BASE + 0x4).unwrap() & stat_bit::RX_NOT_EMPTY,
            0,
            "a second byte is not received while /CS stays high"
        );

        sio.write16(Sio0::BASE + 0xA, ctrl_bit::JOYN_OUTPUT);
        sio.write8(Sio0::BASE, 0x00);
        assert_ne!(
            sio.read32(Sio0::BASE + 0x4).unwrap() & stat_bit::RX_NOT_EMPTY,
            0,
            "selected-port receiving works with CTRL.2 clear"
        );
    }

    #[test]
    fn write_then_read_roundtrips_mode_baud() {
        let mut sio = Sio0::new();
        sio.write16(Sio0::BASE + 0x8, 0x1234);
        sio.write16(Sio0::BASE + 0xE, 0x5678);
        assert_eq!(sio.read16(Sio0::BASE + 0x8).unwrap(), 0x0034);
        assert_eq!(sio.read16(Sio0::BASE + 0xE).unwrap(), 0x5678);
    }

    #[test]
    fn ctrl_reset_bit_zeroes_everything() {
        let mut sio = Sio0::new();
        sio.write16(Sio0::BASE + 0x8, 0xFFFF);
        sio.write16(Sio0::BASE + 0xE, 0xFFFF);
        sio.ack_input = true;
        sio.irq_latched = true;
        sio.write16(Sio0::BASE + 0xA, ctrl_bit::RESET);
        assert_eq!(sio.mode, 0);
        assert_eq!(sio.baud, 0);
        assert_eq!(sio.ctrl, 0);
        assert!(!sio.ack_input);
        assert!(!sio.irq_latched);
    }

    #[test]
    fn ctrl_ack_bit_is_stripped() {
        let mut sio = Sio0::new();
        // Every bit except RESET (0x40); ACK must not be kept.
        sio.write16(Sio0::BASE + 0xA, 0x001F);
        assert_eq!(sio.ctrl & ctrl_bit::ACK, 0);
        // Other low bits pass through (including SIO0's one-shot CTRL.2).
        assert_eq!(sio.ctrl & 0x000F, 0x000F);
    }

    #[test]
    fn contains_matches_full_window() {
        for off in 0..Sio0::SIZE {
            assert!(Sio0::contains(Sio0::BASE + off));
        }
        assert!(!Sio0::contains(Sio0::BASE - 1));
        assert!(!Sio0::contains(Sio0::BASE + Sio0::SIZE));
    }

    #[test]
    fn digital_pad_full_poll_via_mmio() {
        use crate::pad::{button, ButtonState, DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        // Hold Cross + Start.
        sio.set_port1_buttons(ButtonState::from_bits(button::START | button::CROSS));

        // Simulate the BIOS pad-poll sequence on port 1 (SLOT bit clear).
        sio.write16(Sio0::BASE + 0xA, ctrl_bit::JOYN_OUTPUT); // assert JOYN

        // TX 0x01 → RX 0xFF (dummy select-byte response)
        sio.write8(Sio0::BASE, 0x01);
        sio.tick(DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS);
        assert_eq!(sio.pop_rx(), 0xFF);

        // TX 0x42 → RX 0x41
        sio.write8(Sio0::BASE, 0x42);
        sio.tick(2 * (DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS));
        assert_eq!(sio.pop_rx(), 0x41);

        // TX 0x00 → RX 0x5A
        sio.write8(Sio0::BASE, 0x00);
        sio.tick(3 * (DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS));
        assert_eq!(sio.pop_rx(), 0x5A);

        // TX 0x00 → RX buttons1 (START = bit 3 pressed → wire 0xF7)
        sio.write8(Sio0::BASE, 0x00);
        sio.tick(4 * (DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS));
        assert_eq!(sio.pop_rx(), 0xF7);

        // TX 0x00 → RX buttons2 (CROSS = bit 14 pressed → wire 0xBF)
        sio.write8(Sio0::BASE, 0x00);
        sio.tick(4 * (DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS) + DEFAULT_TRANSFER_TICKS);
        assert_eq!(sio.pop_rx(), 0xBF);
    }

    #[test]
    fn slot_bit_switches_ports() {
        use crate::pad::{DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        // Port 2 stays empty.

        // CTRL.SLOT = 1 → port 2 (empty).
        sio.write16(Sio0::BASE + 0xA, ctrl_bit::SLOT | ctrl_bit::JOYN_OUTPUT);
        sio.write8(Sio0::BASE, 0x01);
        sio.tick(DEFAULT_TRANSFER_TICKS);
        assert_eq!(sio.pop_rx(), 0xFF, "empty port 2 returns 0xFF");

        // CTRL.SLOT = 0 → port 1 (has pad).
        sio.write16(Sio0::BASE + 0xA, ctrl_bit::JOYN_OUTPUT);
        sio.write8(Sio0::BASE, 0x01);
        sio.tick(DEFAULT_TRANSFER_TICKS);
        assert_eq!(
            sio.pop_rx(),
            0xFF,
            "port 1 select byte gets the dummy response"
        );
        sio.write8(Sio0::BASE, 0x42);
        sio.tick(DEFAULT_TRANSFER_TICKS * 2);
        assert_eq!(
            sio.pop_rx(),
            0x41,
            "port 1 pad responds on the command byte"
        );
    }

    #[test]
    fn controller_ack_sets_stat_bits_and_irq_when_enabled() {
        use crate::pad::{DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.write16(
            Sio0::BASE + 0xA,
            ctrl_bit::JOYN_OUTPUT | ctrl_bit::ACK_IRQ_ENABLE,
        );

        sio.write8(Sio0::BASE, 0x01);

        let stat = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_ne!(
            stat & stat_bit::RX_NOT_EMPTY,
            0,
            "Redux makes the response byte visible immediately"
        );
        assert_eq!(
            stat & stat_bit::ACK_INPUT,
            0,
            "ACK must wait for the delayed SIO event"
        );
        assert_eq!(stat & stat_bit::IRQ, 0, "IRQ bit must stay low until ACK");
        assert!(
            !sio.take_pending_irq(),
            "bus IRQ should not fire before ACK"
        );

        sio.tick(DEFAULT_TRANSFER_TICKS - 1);
        assert_eq!(
            sio.read32(Sio0::BASE + 0x4).unwrap() & stat_bit::IRQ,
            0,
            "IRQ must not fire before the Redux baud-clocked delay"
        );

        sio.tick(DEFAULT_TRANSFER_TICKS);
        let stat = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_ne!(stat & stat_bit::ACK_INPUT, 0, "ACK input should be visible");
        assert_ne!(stat & stat_bit::IRQ, 0, "STAT IRQ bit should latch");
        assert!(sio.take_pending_irq(), "bus should see one IRQ edge");
        assert!(!sio.take_pending_irq(), "IRQ edge should be single-shot");

        sio.write16(Sio0::BASE + 0xA, ctrl_bit::JOYN_OUTPUT | ctrl_bit::ACK);
        let stat = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_eq!(stat & stat_bit::IRQ, 0, "CTRL.ACK should clear STAT IRQ");
    }

    #[test]
    fn controller_ack_without_irq_enable_is_visible_but_does_not_raise_irq() {
        use crate::pad::{DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.write16(Sio0::BASE + 0xA, ctrl_bit::JOYN_OUTPUT);

        sio.write8(Sio0::BASE, 0x01);
        sio.tick(DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS);

        let stat = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_ne!(
            stat & stat_bit::ACK_INPUT,
            0,
            "ACK input level is independent from ACK IRQ enable"
        );
        assert_eq!(
            stat & stat_bit::IRQ,
            0,
            "IRQ bit should stay low without enable"
        );
        assert!(
            !sio.take_pending_irq(),
            "bus IRQ must stay quiet without enable"
        );
    }

    #[test]
    fn missing_device_returns_ff_without_dsr_timeout_irq() {
        use crate::pad::PortDevice;

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty());
        sio.write16(
            Sio0::BASE + 0xA,
            ctrl_bit::JOYN_OUTPUT | ctrl_bit::ACK_IRQ_ENABLE,
        );
        sio.write16(Sio0::BASE + 0xE, 0x0088);

        sio.write8_at(Sio0::BASE, 0x01, 10);
        assert_eq!(sio.pop_rx(), 0xFF);
        assert_eq!(sio.debug_ack_deadline(), None);
        assert_eq!(
            sio.read32(Sio0::BASE + 0x4).unwrap() & stat_bit::ACK_INPUT,
            0,
            "empty slots must not expose a visible ACK pulse"
        );

        sio.tick(10 + 0x88 * 8);
        assert_eq!(
            sio.read32(Sio0::BASE + 0x4).unwrap() & stat_bit::IRQ,
            0,
            "Redux does not schedule ACK/DSR IRQs for missing devices"
        );
        assert!(!sio.take_pending_irq());
    }

    #[test]
    fn controller_final_no_ack_byte_does_not_arm_timeout_irq() {
        use crate::pad::{DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.write16(
            Sio0::BASE + 0xA,
            ctrl_bit::JOYN_OUTPUT | ctrl_bit::ACK_IRQ_ENABLE,
        );
        sio.write16(Sio0::BASE + 0xE, 0x0088);

        let mut now = 10u64;
        for tx in [0x01, 0x42, 0x00, 0x00] {
            sio.write8_at(Sio0::BASE, tx, now);
            sio.tick(now + 0x88 * 8);
            assert!(sio.take_pending_irq(), "byte 0x{tx:02x} should ACK");
            sio.write16(
                Sio0::BASE + 0xA,
                ctrl_bit::JOYN_OUTPUT | ctrl_bit::ACK_IRQ_ENABLE | ctrl_bit::ACK,
            );
            let _ = sio.read8(Sio0::BASE);
            now += 0x88 * 8 + 1;
        }

        sio.write8_at(Sio0::BASE, 0x00, now);
        assert_eq!(
            sio.debug_ack_deadline(),
            None,
            "the final byte of a real controller poll drops ACK without arming a DSR timeout"
        );
        sio.tick(now + 0x88 * 8);
        assert!(!sio.take_pending_irq());
        assert_eq!(sio.read32(Sio0::BASE + 0x4).unwrap() & stat_bit::IRQ, 0);
    }

    #[test]
    fn successive_controller_acks_wait_for_ctrl_ack_before_reinterrupt() {
        use crate::pad::{DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.write16(
            Sio0::BASE + 0xA,
            ctrl_bit::JOYN_OUTPUT | ctrl_bit::ACK_IRQ_ENABLE,
        );

        sio.write8_at(Sio0::BASE, 0x01, 10);
        sio.tick(10 + DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS);
        assert!(sio.take_pending_irq(), "first ACK should raise an IRQ edge");

        let second_start = 10 + DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS + 1;
        sio.write8_at(Sio0::BASE, 0x42, second_start);
        sio.tick(second_start + DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS);
        assert!(
            !sio.take_pending_irq(),
            "Redux does not schedule another SIO IRQ while STAT.IRQ is still latched"
        );

        sio.write16(
            Sio0::BASE + 0xA,
            ctrl_bit::JOYN_OUTPUT | ctrl_bit::ACK_IRQ_ENABLE | ctrl_bit::ACK,
        );
        sio.write8_at(Sio0::BASE, 0x00, second_start + DEFAULT_TRANSFER_TICKS + 1);
        sio.tick(second_start + 2 * DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS + 1);
        assert!(
            sio.take_pending_irq(),
            "after CTRL.ACK clears STAT.IRQ, a later ACK can raise the next edge"
        );
    }

    #[test]
    fn sdk_style_pad_poll_sequence_completes() {
        use crate::pad::{button, ButtonState, DigitalPad, PortDevice};

        fn wait_for_stat(sio: &mut Sio0, now: &mut u64, mask: u32) {
            const TIMEOUT_TICKS: u64 = 10_000;
            let start = *now;
            while sio.read32(Sio0::BASE + 0x4).unwrap() & mask == 0 {
                *now = now.saturating_add(1);
                sio.tick(*now);
                assert!(
                    *now - start < TIMEOUT_TICKS,
                    "timed out waiting for STAT mask {mask:#x}"
                );
            }
        }

        fn exchange_sdk_style(sio: &mut Sio0, now: &mut u64, tx: u8) -> u8 {
            wait_for_stat(sio, now, stat_bit::TX_READY_1);
            sio.write8(Sio0::BASE, tx);
            wait_for_stat(sio, now, stat_bit::RX_NOT_EMPTY);
            sio.read8(Sio0::BASE).unwrap()
        }

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.set_port1_buttons(ButtonState::from_bits(button::START | button::CROSS));

        let mut now = 0u64;
        // Match psx-pad's init sequence: ACK any stale IRQ, then
        // assert JOYN with TX enabled; selected-port RX is implicit.
        sio.write16(Sio0::BASE + 0xA, ctrl_bit::ACK);
        sio.write16(
            Sio0::BASE + 0xA,
            (1 << 0) | ctrl_bit::JOYN_OUTPUT | (1 << 2),
        );

        assert_eq!(exchange_sdk_style(&mut sio, &mut now, 0x01), 0xFF);
        assert_eq!(exchange_sdk_style(&mut sio, &mut now, 0x42), 0x41);
        assert_eq!(exchange_sdk_style(&mut sio, &mut now, 0x00), 0x5A);
        assert_eq!(exchange_sdk_style(&mut sio, &mut now, 0x00), 0xF7);
        assert_eq!(exchange_sdk_style(&mut sio, &mut now, 0x00), 0xBF);
    }

    #[test]
    fn redux_style_transmit_keeps_tx_ready_high_while_irq_is_delayed() {
        use crate::pad::{DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.write16(
            Sio0::BASE + 0xA,
            ctrl_bit::JOYN_OUTPUT | ctrl_bit::ACK_IRQ_ENABLE,
        );
        sio.write16(Sio0::BASE + 0xE, 0x0088);

        sio.write8_at(Sio0::BASE, 0x01, 10);
        let stat = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_ne!(
            stat & stat_bit::TX_READY_2,
            0,
            "Redux completes the byte synchronously and keeps TX_READY_2 high"
        );
        assert_ne!(
            stat & stat_bit::RX_NOT_EMPTY,
            0,
            "response byte should be readable immediately"
        );

        sio.tick(10 + 0x88 * 8 - 1);
        let stat = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_eq!(stat & stat_bit::IRQ, 0, "only the SIO IRQ edge is delayed");

        sio.tick(10 + 0x88 * 8);
        let stat = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_ne!(
            stat & stat_bit::IRQ,
            0,
            "IRQ should latch at the Redux baud-clocked deadline"
        );
    }

    #[test]
    fn tx_ready_1_stays_high_across_successive_synchronous_writes() {
        use crate::pad::{DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.write16(Sio0::BASE + 0xA, ctrl_bit::JOYN_OUTPUT);

        sio.write8_at(Sio0::BASE, 0x01, 10);
        let stat = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_ne!(
            stat & stat_bit::TX_READY_1,
            0,
            "TX_READY_1 should stay set after synchronous select byte"
        );
        assert_eq!(sio.pop_rx(), 0xFF);

        sio.write8_at(Sio0::BASE, 0x42, 11);
        let stat = sio.read32(Sio0::BASE + 0x4).unwrap();
        assert_ne!(
            stat & stat_bit::TX_READY_1,
            0,
            "second write should not fill a deferred TX queue"
        );
        assert_eq!(sio.pop_rx(), 0x41);
        assert_ne!(
            sio.read32(Sio0::BASE + 0x4).unwrap() & stat_bit::TX_READY_1,
            0,
            "TX_READY_1 remains high after DATA is consumed"
        );
    }

    #[test]
    fn successive_writes_advance_pad_state_synchronously() {
        use crate::pad::{DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.write16(
            Sio0::BASE + 0xA,
            ctrl_bit::JOYN_OUTPUT | ctrl_bit::ACK_IRQ_ENABLE,
        );

        sio.write8_at(Sio0::BASE, 0x01, 10);
        assert_eq!(
            sio.pop_rx(),
            0xFF,
            "select byte response should be available before the IRQ event"
        );
        assert_eq!(
            sio.debug_ack_deadline(),
            Some(10 + DEFAULT_TRANSFER_TICKS),
            "first byte should still schedule a delayed SIO event"
        );

        sio.write8_at(Sio0::BASE, 0x42, 11);
        assert_eq!(
            sio.pop_rx(),
            0x41,
            "command byte response should also be immediate"
        );
        assert_eq!(
            sio.debug_ack_deadline(),
            Some(11 + DEFAULT_TRANSFER_TICKS),
            "new synchronous byte should replace the next delayed IRQ deadline"
        );
    }

    #[test]
    fn slow_pad_desyncs_without_ack_wait() {
        use crate::pad::{button, ButtonState, DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.set_port1_buttons(ButtonState::from_bits(button::START));
        sio.set_slow_pad(true);
        sio.write16(Sio0::BASE + 0xE, 0x0088); // baud -> transfer_ticks = 1088
        sio.write16(Sio0::BASE + 0xA, ctrl_bit::JOYN_OUTPUT); // select port 1

        let mut now = 100u64;
        // The select byte is always fine (no prior /ACK deadline to beat).
        sio.write8_at(Sio0::BASE, 0x01, now);
        assert_eq!(sio.pop_rx(), 0xFF);

        // The command byte is clocked only a few cycles later -- long before the
        // slow pad's /ACK deadline (now + 1088) -- so the device misses it.
        now += 8;
        sio.write8_at(Sio0::BASE, 0x42, now);
        assert_eq!(
            sio.pop_rx(),
            0xFF,
            "a slow pad must not return its 0x41 id when the host skips the /ACK wait"
        );

        // Every subsequent byte of the packet stays desynced.
        now += 8;
        sio.write8_at(Sio0::BASE, 0x00, now);
        assert_eq!(
            sio.pop_rx(),
            0xFF,
            "packet remains desynced after a missed byte"
        );
    }

    #[test]
    fn slow_pad_reads_clean_with_ack_wait() {
        use crate::pad::{button, ButtonState, DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.set_port1_buttons(ButtonState::from_bits(button::START | button::CROSS));
        sio.set_slow_pad(true);
        sio.write16(Sio0::BASE + 0xE, 0x0088);
        sio.write16(Sio0::BASE + 0xA, ctrl_bit::JOYN_OUTPUT);

        // Mirror the ACK-paced driver: wait past each byte's /ACK deadline
        // (transfer_ticks = 0x88 * 8 = 1088) before clocking the next byte.
        let gap = 0x88u64 * 8 + 16;
        let mut now = 100u64;
        let ex = |sio: &mut Sio0, now: &mut u64, tx: u8| -> u8 {
            sio.write8_at(Sio0::BASE, tx, *now);
            sio.tick(*now);
            let rx = sio.read8(Sio0::BASE).unwrap();
            *now += gap; // host waited for /ACK before clocking the next byte
            rx
        };

        assert_eq!(ex(&mut sio, &mut now, 0x01), 0xFF);
        assert_eq!(ex(&mut sio, &mut now, 0x42), 0x41, "id after /ACK wait");
        assert_eq!(ex(&mut sio, &mut now, 0x00), 0x5A, "magic after /ACK wait");
        assert_eq!(ex(&mut sio, &mut now, 0x00), 0xF7, "buttons1 (START)");
        assert_eq!(ex(&mut sio, &mut now, 0x00), 0xBF, "buttons2 (CROSS)");
    }

    #[test]
    fn ack_input_is_a_pulse_not_a_sticky_level() {
        use crate::pad::{DigitalPad, PortDevice};

        let mut sio = Sio0::new();
        sio.attach_port1(PortDevice::empty().with_pad(DigitalPad::new()));
        sio.write16(
            Sio0::BASE + 0xA,
            ctrl_bit::JOYN_OUTPUT | ctrl_bit::ACK_IRQ_ENABLE,
        );

        sio.write8_at(Sio0::BASE, 0x01, 100);
        sio.tick(100 + DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS);
        assert_ne!(
            sio.read32(Sio0::BASE + 0x4).unwrap() & stat_bit::ACK_INPUT,
            0,
            "ACK pulse should become visible"
        );

        sio.tick(100 + DEFAULT_TRANSFER_TICKS + PAD_ACK_DELAY_TICKS + ACK_PULSE_TICKS);
        assert_eq!(
            sio.read32(Sio0::BASE + 0x4).unwrap() & stat_bit::ACK_INPUT,
            0,
            "ACK pulse should self-clear"
        );
    }
}
