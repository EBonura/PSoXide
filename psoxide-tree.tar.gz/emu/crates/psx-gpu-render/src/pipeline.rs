//! wgpu render pipeline + per-frame buffers for the HW renderer.

use wgpu::util::DeviceExt;

use crate::target::{TARGET_FORMAT, VRAM_HEIGHT, VRAM_WIDTH};

/// Per-vertex data. 20 bytes, `bytemuck::Pod` so we can blit a
/// `Vec<HwVertex>` into the GPU vertex buffer with `cast_slice`.
///
/// `flags` and `tex_window` pack the per-primitive state the fragment
/// shader needs -- the format is identical across primitives, so a
/// single draw call handles mixed textured / mono / different
/// tpages / different CLUTs in one batch. See [`flags`] module for
/// the bit layout (host + WGSL must agree).
#[repr(C)]
#[derive(Copy, Clone, Debug, Default, bytemuck::Pod, bytemuck::Zeroable)]
pub struct HwVertex {
    /// PSX screen-space coords (post-`draw_offset`).
    pub pos: [i16; 2],
    /// Tint or per-vertex colour, 0..=255 per channel. Modulates
    /// the sampled texel for textured primitives unless
    /// `flags::RAW_TEXTURE` is set.
    pub color: [u8; 4],
    /// Texture UV in PSX texture-page-space, 0..=255 per axis.
    /// `u16` for vertex-attribute alignment; PSX only emits 8-bit
    /// values today.
    pub uv: [u16; 2],
    /// Bit-packed per-primitive state. See [`flags`].
    pub flags: u32,
    /// Packed texture-window state: mask_x, mask_y, offset_x,
    /// offset_y in the same pre-shifted pixel units used by the
    /// CPU GPU path.
    pub tex_window: u32,
}

/// `HwVertex::flags` bit layout. Host + shader must agree --
/// any change here needs the matching constants in
/// `shaders/prim.wgsl` updated in lockstep.
///
/// Layout (low bit first):
/// ```text
/// bits  0..=3   tpage_x_units (0..15)         tpage_x = units * 64
/// bit       4   tpage_y_index (0 or 1)        tpage_y = index * 256
/// bits  5..=6   tex_depth (0=4bpp, 1=8bpp, 2=15bpp)
/// bits  7..=12  clut_x_units  (0..63)         clut_x  = units * 16
/// bits 13..=21  clut_y         (0..511)
/// bit      22   TEXTURED                      else flat color
/// bit      23   RAW_TEXTURE                   skip tint modulate
/// bit      24   SEMI_TRANS                    routed to a non-Opaque batch
/// bit      25   TEX_OPAQUE_PASS               discard STP texels
/// bit      26   TEX_SEMI_PASS                 keep only STP texels
/// bit      27   DITHER                        GP0(E1) bit 9 was set
/// ```
///
/// Texture-window state deliberately lives in
/// [`HwVertex::tex_window`] instead of these bits: GP0(E2) needs four
/// 8-bit fields, and the low flag word is already dense.
pub mod flags {
    pub const TEXTURED: u32 = 1 << 22;
    pub const RAW_TEXTURE: u32 = 1 << 23;
    pub const SEMI_TRANS: u32 = 1 << 24;
    pub const TEX_OPAQUE_PASS: u32 = 1 << 25;
    pub const TEX_SEMI_PASS: u32 = 1 << 26;
    /// GP0(E1) bit 9 (or the per-primitive tpage word's copy of it)
    /// was set for this primitive. The fragment shader then applies
    /// the 4x4 ordered dither and truncates to 15bpp, matching
    /// `emulator-core`'s `dither_rgb` / `modulate_tint_dithered`.
    pub const DITHER: u32 = 1 << 27;

    /// Pack tpage origin (in pixels) into the flag bits.
    /// `tpage_x` must be a multiple of 64 (PSX alignment),
    /// `tpage_y` must be 0 or 256.
    pub fn pack_tpage(tpage_x: u32, tpage_y: u32, depth: u32) -> u32 {
        let tx = (tpage_x / 64) & 0xF;
        let ty = if tpage_y >= 256 { 1u32 } else { 0u32 };
        let d = depth & 0x3;
        tx | (ty << 4) | (d << 5)
    }

    /// Pack CLUT origin (in pixels) into the flag bits.
    /// `clut_x` must be a multiple of 16, `clut_y` must be 0..=511.
    pub fn pack_clut(clut_x: u32, clut_y: u32) -> u32 {
        let cx = (clut_x / 16) & 0x3F;
        let cy = clut_y & 0x1FF;
        (cx << 7) | (cy << 13)
    }
}

/// Initial vertex-buffer capacity. PSX games very rarely exceed a
/// few thousand primitives per frame; 16 K vertices ≈ 5 K mono
/// triangles is plenty of headroom for Phase 1. Grown on demand
/// (re-allocates the wgpu buffer; cheap because it happens once
/// then the high-water-mark sticks).
const INITIAL_VERTEX_CAPACITY: u64 = 16 * 1024;

/// Per-primitive PSX blend mode. Maps 1:1 to one of the 5 render
/// pipelines `HwPipeline` builds -- the translator sorts vertices
/// into contiguous batches by `BlendKind`, the renderer issues
/// one draw per batch with the matching pipeline + blend constant.
///
/// Numeric discriminants are stable so they can index into the
/// pipeline / blend-constant arrays directly.
#[derive(Copy, Clone, Debug, PartialEq, Eq)]
#[repr(u8)]
pub enum BlendKind {
    /// `cmd-bit-25` clear → standard opaque draw, `BlendState::REPLACE`.
    Opaque = 0,
    /// PSX semi-trans mode 0: `(B + F) / 2`. Implemented as
    /// `Constant * F + Constant * B` with blend_constant = 0.5.
    Average = 1,
    /// PSX semi-trans mode 1: `B + F`. `One * F + One * B`.
    Add = 2,
    /// PSX semi-trans mode 2: `B - F`. `One * B - One * F` (reverse subtract).
    Sub = 3,
    /// PSX semi-trans mode 3: `B + F/4`. `Constant * F + One * B` with
    /// blend_constant = 0.25.
    AddQuarter = 4,
}

impl BlendKind {
    pub const COUNT: usize = 5;

    pub fn index(self) -> usize {
        self as usize
    }
}

/// Blend-constant value to bind before a batch's draw call.
/// Only Average / AddQuarter use it; the others ignore it.
fn blend_constant_for(kind: BlendKind) -> wgpu::Color {
    let v = match kind {
        BlendKind::Average => 0.5,
        BlendKind::AddQuarter => 0.25,
        _ => 0.0,
    };
    wgpu::Color {
        r: v,
        g: v,
        b: v,
        a: v,
    }
}

pub struct HwPipeline {
    /// One render pipeline per [`BlendKind`]. Same shader, same
    /// vertex layout -- only `BlendState` differs. Indexed by
    /// `BlendKind::index()`.
    pipelines: [wgpu::RenderPipeline; BlendKind::COUNT],
    /// Fullscreen VRAM->target blit used by wireframe mode.
    blit_pipeline: wgpu::RenderPipeline,
    bind_group_layout: wgpu::BindGroupLayout,
    bind_group: wgpu::BindGroup,
    vertex_buffer: wgpu::Buffer,
    vertex_capacity_bytes: u64,
    /// VRAM texture sampled by the fragment shader for textured
    /// primitives. `R16Uint`, 1024×512, populated each frame from
    /// CPU `Vram` via `upload_vram`. `R16Uint` (vs the existing
    /// `Rgba8UnormSrgb` VRAM viewer texture) preserves PSX BGR15
    /// bit-exactly so the shader can decode 4/8/15 bpp and CLUT
    /// indices without going through sRGB / replication.
    vram_texture: wgpu::Texture,
    /// Held alive so the bind group's `TextureView` reference
    /// stays valid for the life of the pipeline. Read indirectly
    /// through the bind group; never queried directly.
    #[allow(dead_code)]
    vram_view: wgpu::TextureView,
    /// Texture-filter mode uniform (0 nearest, 1 bilinear, 2 JINC2, 3 xBR).
    filter_buffer: wgpu::Buffer,
}

impl HwPipeline {
    pub fn new(device: &wgpu::Device) -> Self {
        let shader = device.create_shader_module(wgpu::ShaderModuleDescriptor {
            label: Some("psx-hw-prim"),
            source: wgpu::ShaderSource::Wgsl(include_str!("shaders/prim.wgsl").into()),
        });

        // VRAM as a 1024×512 R16Uint texture. Filled each frame
        // by `upload_vram`. The fragment shader reads from it via
        // `textureLoad` (no filtering -- every PSX texture access
        // is integer-addressed).
        let vram_texture = device.create_texture(&wgpu::TextureDescriptor {
            label: Some("psx-hw-vram-r16uint"),
            size: wgpu::Extent3d {
                width: VRAM_WIDTH,
                height: VRAM_HEIGHT,
                depth_or_array_layers: 1,
            },
            mip_level_count: 1,
            sample_count: 1,
            dimension: wgpu::TextureDimension::D2,
            format: wgpu::TextureFormat::R16Uint,
            usage: wgpu::TextureUsages::TEXTURE_BINDING | wgpu::TextureUsages::COPY_DST,
            view_formats: &[],
        });
        let vram_view = vram_texture.create_view(&wgpu::TextureViewDescriptor::default());

        // 16-byte uniform: texture-filter mode in `.x` (0 nearest, 1 bilinear,
        // 2 JINC2, 3 xBR; the UI currently exposes 0 and 3).
        let filter_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("psx-hw-texfilter"),
            contents: bytemuck::cast_slice(&[0u32; 4]),
            usage: wgpu::BufferUsages::UNIFORM | wgpu::BufferUsages::COPY_DST,
        });

        let bind_group_layout = device.create_bind_group_layout(&wgpu::BindGroupLayoutDescriptor {
            label: Some("psx-hw-bgl"),
            entries: &[
                // 0: VRAM texture (fragment shader).
                wgpu::BindGroupLayoutEntry {
                    binding: 0,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Texture {
                        sample_type: wgpu::TextureSampleType::Uint,
                        view_dimension: wgpu::TextureViewDimension::D2,
                        multisampled: false,
                    },
                    count: None,
                },
                // 1: texture-filter mode uniform.
                wgpu::BindGroupLayoutEntry {
                    binding: 1,
                    visibility: wgpu::ShaderStages::FRAGMENT,
                    ty: wgpu::BindingType::Buffer {
                        ty: wgpu::BufferBindingType::Uniform,
                        has_dynamic_offset: false,
                        min_binding_size: None,
                    },
                    count: None,
                },
            ],
        });

        let bind_group = device.create_bind_group(&wgpu::BindGroupDescriptor {
            label: Some("psx-hw-bg"),
            layout: &bind_group_layout,
            entries: &[
                wgpu::BindGroupEntry {
                    binding: 0,
                    resource: wgpu::BindingResource::TextureView(&vram_view),
                },
                wgpu::BindGroupEntry {
                    binding: 1,
                    resource: filter_buffer.as_entire_binding(),
                },
            ],
        });

        let pipeline_layout = device.create_pipeline_layout(&wgpu::PipelineLayoutDescriptor {
            label: Some("psx-hw-pl"),
            bind_group_layouts: &[&bind_group_layout],
            push_constant_ranges: &[],
        });

        let vertex_layout = wgpu::VertexBufferLayout {
            array_stride: std::mem::size_of::<HwVertex>() as u64,
            step_mode: wgpu::VertexStepMode::Vertex,
            attributes: &[
                // pos: i16x2 → Sint16x2 (2 × 2 bytes = 4)
                wgpu::VertexAttribute {
                    format: wgpu::VertexFormat::Sint16x2,
                    offset: 0,
                    shader_location: 0,
                },
                // color: u8x4 → Unorm8x4 (4 bytes), offset 4
                wgpu::VertexAttribute {
                    format: wgpu::VertexFormat::Unorm8x4,
                    offset: 4,
                    shader_location: 1,
                },
                // uv: u16x2 → Uint16x2 (2 × 2 = 4 bytes), offset 8
                wgpu::VertexAttribute {
                    format: wgpu::VertexFormat::Uint16x2,
                    offset: 8,
                    shader_location: 2,
                },
                // flags: u32 → Uint32 (4 bytes), offset 12
                wgpu::VertexAttribute {
                    format: wgpu::VertexFormat::Uint32,
                    offset: 12,
                    shader_location: 3,
                },
                // tex_window: u32 → Uint32 (4 bytes), offset 16
                wgpu::VertexAttribute {
                    format: wgpu::VertexFormat::Uint32,
                    offset: 16,
                    shader_location: 4,
                },
            ],
        };

        // Build five render-pipeline variants, one per BlendKind.
        // Same shader + same vertex layout; only the color
        // attachment's `BlendState` differs. Translator picks the
        // right pipeline per primitive at draw time.
        let make_pipeline = |label: &str, blend: wgpu::BlendState| {
            device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
                label: Some(label),
                layout: Some(&pipeline_layout),
                vertex: wgpu::VertexState {
                    module: &shader,
                    entry_point: Some("vs_main"),
                    buffers: std::slice::from_ref(&vertex_layout),
                    compilation_options: Default::default(),
                },
                primitive: wgpu::PrimitiveState {
                    topology: wgpu::PrimitiveTopology::TriangleList,
                    strip_index_format: None,
                    front_face: wgpu::FrontFace::Ccw,
                    // PSX has no winding constraint -- quads / rects
                    // come in with mixed windings depending on game
                    // UV layout.
                    cull_mode: None,
                    polygon_mode: wgpu::PolygonMode::Fill,
                    unclipped_depth: false,
                    conservative: false,
                },
                depth_stencil: None,
                multisample: wgpu::MultisampleState::default(),
                fragment: Some(wgpu::FragmentState {
                    module: &shader,
                    entry_point: Some("fs_main"),
                    targets: &[Some(wgpu::ColorTargetState {
                        format: TARGET_FORMAT,
                        blend: Some(blend),
                        write_mask: wgpu::ColorWrites::ALL,
                    })],
                    compilation_options: Default::default(),
                }),
                multiview: None,
                cache: None,
            })
        };
        let pipelines = [
            make_pipeline("psx-hw-pipeline-opaque", wgpu::BlendState::REPLACE),
            make_pipeline("psx-hw-pipeline-average", blend_state_average()),
            make_pipeline("psx-hw-pipeline-add", blend_state_add()),
            make_pipeline("psx-hw-pipeline-sub", blend_state_sub()),
            make_pipeline("psx-hw-pipeline-add-quarter", blend_state_add_quarter()),
        ];

        // Fullscreen VRAM->target blit (wireframe mode rebuilds the
        // persistent target from clean CPU VRAM each frame). No vertex
        // buffer; same bind group (only binding 0 is read).
        let blit_pipeline = device.create_render_pipeline(&wgpu::RenderPipelineDescriptor {
            label: Some("psx-hw-pipeline-blit"),
            layout: Some(&pipeline_layout),
            vertex: wgpu::VertexState {
                module: &shader,
                entry_point: Some("vs_blit"),
                buffers: &[],
                compilation_options: Default::default(),
            },
            primitive: wgpu::PrimitiveState::default(),
            depth_stencil: None,
            multisample: wgpu::MultisampleState::default(),
            fragment: Some(wgpu::FragmentState {
                module: &shader,
                entry_point: Some("fs_blit"),
                targets: &[Some(wgpu::ColorTargetState {
                    format: TARGET_FORMAT,
                    blend: Some(wgpu::BlendState::REPLACE),
                    write_mask: wgpu::ColorWrites::ALL,
                })],
                compilation_options: Default::default(),
            }),
            multiview: None,
            cache: None,
        });

        let vertex_capacity_bytes =
            INITIAL_VERTEX_CAPACITY * std::mem::size_of::<HwVertex>() as u64;
        let vertex_buffer = device.create_buffer_init(&wgpu::util::BufferInitDescriptor {
            label: Some("psx-hw-vertices"),
            contents: &vec![0u8; vertex_capacity_bytes as usize],
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
        });

        Self {
            pipelines,
            blit_pipeline,
            bind_group_layout,
            bind_group,
            vertex_buffer,
            vertex_capacity_bytes,
            vram_texture,
            vram_view,
            filter_buffer,
        }
    }

    /// The fullscreen VRAM->target blit pipeline (3 vertices, no buffers).
    pub fn blit_pipeline(&self) -> &wgpu::RenderPipeline {
        &self.blit_pipeline
    }

    /// Set the texture-filter mode (0 nearest, 1 bilinear, 2 JINC2, 3 xBR).
    /// Cheap uniform write.
    pub fn set_filter_mode(&self, queue: &wgpu::Queue, mode: u32) {
        queue.write_buffer(&self.filter_buffer, 0, bytemuck::cast_slice(&[mode]));
    }

    /// Publish the internal-resolution multiplier to `.y` of the same
    /// uniform. The dither path needs it to recover the PSX-native
    /// pixel coordinate from the S-times-denser fragment coordinate.
    pub fn set_internal_scale(&self, queue: &wgpu::Queue, scale: u32) {
        queue.write_buffer(&self.filter_buffer, 4, bytemuck::cast_slice(&[scale.max(1)]));
    }

    /// Mirror CPU VRAM into the GPU-side `R16Uint` texture used by
    /// the fragment shader. Cheap full-frame upload (1 MiB / frame)
    /// -- same cost the existing `Graphics::prepare_vram` already
    /// pays for the VRAM viewer panel. Phase 7 may dirty-track
    /// regions to skip unchanged frames; for now full-upload keeps
    /// the renderer obviously correct.
    pub fn upload_vram(&self, queue: &wgpu::Queue, words: &[u16]) {
        if words.len() != (VRAM_WIDTH * VRAM_HEIGHT) as usize {
            return;
        }
        queue.write_texture(
            wgpu::TexelCopyTextureInfo {
                texture: &self.vram_texture,
                mip_level: 0,
                origin: wgpu::Origin3d::ZERO,
                aspect: wgpu::TextureAspect::All,
            },
            bytemuck::cast_slice(words),
            wgpu::TexelCopyBufferLayout {
                offset: 0,
                bytes_per_row: Some(VRAM_WIDTH * 2),
                rows_per_image: Some(VRAM_HEIGHT),
            },
            wgpu::Extent3d {
                width: VRAM_WIDTH,
                height: VRAM_HEIGHT,
                depth_or_array_layers: 1,
            },
        );
    }

    /// Upload a wrapped sub-rect into the GPU-side `R16Uint` VRAM
    /// texture. Used by the live renderer's command-ordered VRAM
    /// mirror so texture reads see CPU→VRAM uploads and VRAM copies
    /// at the right point in the GP0 stream.
    pub fn upload_vram_rect_wrapped(
        &self,
        queue: &wgpu::Queue,
        x: u32,
        y: u32,
        w: u32,
        h: u32,
        pixel_at: impl Fn(u32, u32) -> u16,
    ) {
        if w == 0 || h == 0 {
            return;
        }

        let mut row = 0;
        while row < h {
            let dst_y = (y + row) & (VRAM_HEIGHT - 1);
            let chunk_h = (h - row).min(VRAM_HEIGHT - dst_y);
            let mut col = 0;
            while col < w {
                let dst_x = (x + col) & (VRAM_WIDTH - 1);
                let chunk_w = (w - col).min(VRAM_WIDTH - dst_x);

                let row_bytes = chunk_w * 2;
                let align = wgpu::COPY_BYTES_PER_ROW_ALIGNMENT;
                let padded_row_bytes = row_bytes.div_ceil(align) * align;
                let padded_words = padded_row_bytes as usize / 2;
                let mut words = vec![0u16; padded_words * chunk_h as usize];

                for src_y in 0..chunk_h {
                    let dst_row = src_y as usize * padded_words;
                    for src_x in 0..chunk_w {
                        words[dst_row + src_x as usize] = pixel_at(col + src_x, row + src_y);
                    }
                }

                queue.write_texture(
                    wgpu::TexelCopyTextureInfo {
                        texture: &self.vram_texture,
                        mip_level: 0,
                        origin: wgpu::Origin3d {
                            x: dst_x,
                            y: dst_y,
                            z: 0,
                        },
                        aspect: wgpu::TextureAspect::All,
                    },
                    bytemuck::cast_slice(&words),
                    wgpu::TexelCopyBufferLayout {
                        offset: 0,
                        bytes_per_row: Some(padded_row_bytes),
                        rows_per_image: Some(chunk_h),
                    },
                    wgpu::Extent3d {
                        width: chunk_w,
                        height: chunk_h,
                        depth_or_array_layers: 1,
                    },
                );

                col += chunk_w;
            }
            row += chunk_h;
        }
    }

    pub fn pipeline(&self, kind: BlendKind) -> &wgpu::RenderPipeline {
        &self.pipelines[kind.index()]
    }

    /// Blend constant the given kind expects bound before its
    /// draw call (`set_blend_constant`). Opaque / Add / Sub
    /// don't use it; we still bind a defined value for
    /// determinism.
    pub fn blend_constant(&self, kind: BlendKind) -> wgpu::Color {
        blend_constant_for(kind)
    }

    pub fn bind_group(&self) -> &wgpu::BindGroup {
        &self.bind_group
    }

    pub fn vertex_buffer(&self) -> &wgpu::Buffer {
        &self.vertex_buffer
    }

    /// Upload the frame's vertex data, growing the GPU-side vertex
    /// buffer when debug modes or primitive-heavy games exceed the
    /// previous high-water mark. Wireframe can multiply polygon
    /// output by 6x, so truncating here would leave later draw ranges
    /// pointing past the bound buffer and trip wgpu validation.
    pub fn upload_vertices(&mut self, device: &wgpu::Device, queue: &wgpu::Queue, bytes: &[u8]) {
        self.ensure_vertex_capacity(device, bytes.len() as u64);
        if !bytes.is_empty() {
            queue.write_buffer(&self.vertex_buffer, 0, bytes);
        }
    }

    fn ensure_vertex_capacity(&mut self, device: &wgpu::Device, required_bytes: u64) {
        if required_bytes <= self.vertex_capacity_bytes {
            return;
        }
        self.vertex_capacity_bytes =
            grown_vertex_capacity_bytes(self.vertex_capacity_bytes, required_bytes);
        self.vertex_buffer = device.create_buffer(&wgpu::BufferDescriptor {
            label: Some("psx-hw-vertices"),
            size: self.vertex_capacity_bytes,
            usage: wgpu::BufferUsages::VERTEX | wgpu::BufferUsages::COPY_DST,
            mapped_at_creation: false,
        });
    }

    /// Vertex-buffer capacity in bytes (sticky high-water mark).
    /// Translator can use this to cap its emission so we never
    /// truncate. The initial allocation covers 16 K vertices and
    /// then grows to a byte-aligned power-of-two high-water mark.
    pub fn vertex_capacity_bytes(&self) -> u64 {
        self.vertex_capacity_bytes
    }
}

// `bind_group_layout` exists on the pipeline for future bind-group
// rebuilds (when texture bindings land in Phase 2). Silence the
// dead-code lint until then.
#[allow(dead_code)]
fn _bgl_used(p: &HwPipeline) -> &wgpu::BindGroupLayout {
    &p.bind_group_layout
}

fn grown_vertex_capacity_bytes(current: u64, required: u64) -> u64 {
    let doubled = current.saturating_mul(2);
    doubled.max(required).next_power_of_two()
}

// ---- PSX semi-trans blend states ----
//
// All four reuse the same factors for color and alpha (alpha
// channel of the output is unused by egui's display path; we
// just keep it consistent). The blend constant is bound per draw
// call via `RenderPass::set_blend_constant`. PSX doesn't need
// per-component constants -- same value on R/G/B/A is fine.

/// PSX mode 0 -- `(B + F) / 2`. With blend_constant = 0.5,
/// `Constant * F + Constant * B = 0.5*F + 0.5*B`.
fn blend_state_average() -> wgpu::BlendState {
    let c = wgpu::BlendComponent {
        src_factor: wgpu::BlendFactor::Constant,
        dst_factor: wgpu::BlendFactor::Constant,
        operation: wgpu::BlendOperation::Add,
    };
    wgpu::BlendState { color: c, alpha: c }
}

/// PSX mode 1 -- `B + F`. Plain additive: `One*F + One*B`.
fn blend_state_add() -> wgpu::BlendState {
    let c = wgpu::BlendComponent {
        src_factor: wgpu::BlendFactor::One,
        dst_factor: wgpu::BlendFactor::One,
        operation: wgpu::BlendOperation::Add,
    };
    wgpu::BlendState { color: c, alpha: c }
}

/// PSX mode 2 -- `B - F`. Reverse-subtract gives
/// `One*B - One*F = B - F`.
fn blend_state_sub() -> wgpu::BlendState {
    let c = wgpu::BlendComponent {
        src_factor: wgpu::BlendFactor::One,
        dst_factor: wgpu::BlendFactor::One,
        operation: wgpu::BlendOperation::ReverseSubtract,
    };
    wgpu::BlendState { color: c, alpha: c }
}

/// PSX mode 3 -- `B + F/4`. `Constant=0.25`,
/// `Constant*F + One*B = 0.25*F + B`.
fn blend_state_add_quarter() -> wgpu::BlendState {
    let c = wgpu::BlendComponent {
        src_factor: wgpu::BlendFactor::Constant,
        dst_factor: wgpu::BlendFactor::One,
        operation: wgpu::BlendOperation::Add,
    };
    wgpu::BlendState { color: c, alpha: c }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn vertex_capacity_growth_covers_wireframe_spikes() {
        let initial = INITIAL_VERTEX_CAPACITY * std::mem::size_of::<HwVertex>() as u64;
        let required = 22_758 * std::mem::size_of::<HwVertex>() as u64;
        let grown = grown_vertex_capacity_bytes(initial, required);

        assert!(grown >= required);
        assert_eq!(grown, (initial * 2).next_power_of_two());
    }

    #[test]
    fn vertex_capacity_growth_keeps_power_of_two_high_water_mark() {
        assert_eq!(grown_vertex_capacity_bytes(256, 257), 512);
        assert_eq!(grown_vertex_capacity_bytes(256, 900), 1024);
    }
}
