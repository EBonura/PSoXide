//! Validation and cooking for authored grid worlds.
//!
//! The output here is still an owned host-side manifest. A later writer can
//! turn it into a compact `.psxw` blob or static Rust arrays for
//! `psx_engine::GridWorld`.

use std::collections::HashMap;

use psxed_format::world;

use crate::{
    snap_world_sector_size, GridDirection, GridHorizontalFace, GridSector, GridSplit,
    GridVerticalFace, GridWalls, MaterialAnimation, MaterialFaceSidedness, MaterialResource,
    ProjectDocument, PsxBlendMode, ResourceData, ResourceId, WallCorner, WorldGrid, HEIGHT_QUANTUM,
    MAX_ROOM_BYTES, MAX_ROOM_DEPTH, MAX_ROOM_TRIANGLES, MAX_ROOM_WIDTH, MAX_WALL_STACK,
    WORLD_SECTOR_SIZE_QUANTUM,
};

mod coords;
mod encode;
mod materials;
mod validation;

/// Neutral baked light used when static vertex lighting is not
/// enabled for a cooked grid. Runtime ignores these bytes unless
/// the `.psxw` world flag opts in.
pub const DEFAULT_BAKED_VERTEX_RGB: [[u8; 3]; 4] = [[255, 255, 255]; 4];

use coords::{
    runtime_horizontal_heights, runtime_horizontal_split, runtime_horizontal_uvs,
    runtime_wall_direction, runtime_wall_heights, runtime_wall_shape, runtime_wall_uvs,
};
use encode::encode_cooked_world_grid_psxw;
use materials::material_slot;
use validation::{
    validate_grid_budget, validate_grid_shape, validate_no_duplicate_walls,
    validate_quantized_heights, validate_wall_heights,
};

/// Authored grid face referenced by a cooker diagnostic.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum WorldGridFaceKind {
    /// Sector floor face.
    Floor,
    /// Sector ceiling face.
    Ceiling,
    /// Sector wall in the given direction.
    Wall(GridDirection),
}

impl std::fmt::Display for WorldGridFaceKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::Floor => f.write_str("floor"),
            Self::Ceiling => f.write_str("ceiling"),
            Self::Wall(direction) => write!(f, "{direction:?} wall"),
        }
    }
}

/// Errors raised while validating and cooking an authored grid world.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum WorldGridCookError {
    /// Sector size must be snapped to the editor/runtime sector quantum.
    UnsupportedSectorSize {
        /// Required sector-size quantum.
        expected: i32,
        /// Authored sector size.
        actual: i32,
    },
    /// A grid must have non-zero dimensions.
    InvalidDimensions {
        /// Authored width.
        width: u16,
        /// Authored depth.
        depth: u16,
    },
    /// Flat sector storage does not match `width * depth`.
    SectorStorageLenMismatch {
        /// Expected sector count.
        expected: usize,
        /// Actual sector count.
        actual: usize,
    },
    /// A renderable face has no assigned material.
    UnassignedMaterial {
        /// Sector X coordinate.
        x: u16,
        /// Sector Z coordinate.
        z: u16,
        /// Face that needs a material.
        face: WorldGridFaceKind,
    },
    /// A face references a missing project resource.
    MissingMaterial {
        /// Missing resource id.
        id: ResourceId,
    },
    /// A face references a resource that is not a material.
    ResourceIsNotMaterial {
        /// Resource id.
        id: ResourceId,
    },
    /// Material slot ids must fit in the runtime `u16` slot type.
    TooManyMaterials {
        /// Number of slots requested.
        count: usize,
    },
    /// Sector records must fit in the world format's `u16` count.
    TooManySectors {
        /// Number of sectors requested.
        count: usize,
    },
    /// Wall records must fit in the world format's `u16` count.
    TooManyWalls {
        /// Number of walls requested.
        count: usize,
    },
    /// Encoded payload length must fit in the common asset header.
    EncodedWorldTooLarge {
        /// Encoded payload length.
        bytes: usize,
    },
    /// A wall has one or both top corners below its bottom corners.
    InvalidWallHeights {
        /// Sector X coordinate.
        x: u16,
        /// Sector Z coordinate.
        z: u16,
        /// Wall direction.
        direction: GridDirection,
        /// Authored wall heights.
        heights: [i32; 4],
    },
    /// Diagonal walls (`NorthWestSouthEast` / `NorthEastSouthWest`)
    /// are unsupported by old cooked runtimes. Current `.psxw`
    /// writers keep this variant only for stale diagnostics and
    /// external callers that may still match it.
    UnsupportedDiagonalWall {
        /// Sector X coordinate.
        x: u16,
        /// Sector Z coordinate.
        z: u16,
        /// Diagonal direction.
        direction: GridDirection,
    },
    /// Grid width / depth past the runtime cap. Caught at cook
    /// time so the editor's inspector warning lines up with a
    /// hard failure when the user actually ships.
    RoomDimensionExceeded {
        /// `'X'` or `'Z'`.
        axis: char,
        /// Authored size.
        value: u16,
        /// Cap.
        limit: u16,
    },
    /// Triangle count past `MAX_ROOM_TRIANGLES`.
    RoomTriangleBudgetExceeded {
        /// Triangles the cooker would emit.
        triangles: usize,
        /// Cap.
        limit: usize,
    },
    /// Cooked `.psxw` payload past `MAX_ROOM_BYTES`.
    RoomByteBudgetExceeded {
        /// Estimated wire size.
        bytes: usize,
        /// Cap.
        limit: usize,
    },
    /// Wall stack on a single edge past `MAX_WALL_STACK`.
    WallStackExceeded {
        /// Sector X coordinate.
        x: u16,
        /// Sector Z coordinate.
        z: u16,
        /// Edge.
        direction: GridDirection,
        /// Authored wall count on this edge.
        count: usize,
        /// Cap.
        limit: usize,
    },
    /// Two cells claim the same physical wall -- `East(x, z)`
    /// and `West(x+1, z)` describe the same vertical face, and
    /// authoring both would double-render and double-collide.
    /// The cooker rejects rather than silently dedup-pick: a
    /// future "low-index-cell wins" rule is fine but should be
    /// an explicit cooker pass, not implicit.
    DuplicatePhysicalWall {
        /// First wall's sector.
        x: u16,
        /// First wall's sector.
        z: u16,
        /// First wall's direction.
        direction: GridDirection,
        /// Second wall's sector.
        other_x: u16,
        /// Second wall's sector.
        other_z: u16,
        /// Second wall's direction.
        other_direction: GridDirection,
    },
    /// A vertex height is not aligned to [`HEIGHT_QUANTUM`]. The
    /// editor snaps every drag through `snap_height`; values
    /// that slip through come from programmatic writes, hand-
    /// edited RON, or a legacy project predating the quantum.
    HeightNotQuantized {
        /// Sector X coordinate.
        x: u16,
        /// Sector Z coordinate.
        z: u16,
        /// Which face the height belongs to.
        face: WorldGridFaceKind,
        /// Offending height.
        value: i32,
        /// Required step.
        quantum: i32,
    },
    /// A face has a `dropped_corner` set -- the editor models it
    /// as a triangle, but the current `.psxw` wire format only carries
    /// quad faces. Render / pick / collision in the editor live
    /// preview already honour the drop, but the cooked runtime
    /// payload doesn't have a slot for it yet.
    TriangleFaceNotSupported {
        /// Sector X coordinate.
        x: u16,
        /// Sector Z coordinate.
        z: u16,
        /// Which face is triangulated.
        face: WorldGridFaceKind,
    },
}

impl std::fmt::Display for WorldGridCookError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            Self::UnsupportedSectorSize { expected, actual } => {
                write!(
                    f,
                    "unsupported sector size {actual}; expected {expected}-unit increments"
                )
            }
            Self::InvalidDimensions { width, depth } => {
                write!(f, "invalid grid dimensions {width} x {depth}")
            }
            Self::SectorStorageLenMismatch { expected, actual } => {
                write!(f, "grid stores {actual} sectors; expected {expected}")
            }
            Self::UnassignedMaterial { x, z, face } => {
                write!(f, "sector {x},{z} {face} has no material")
            }
            Self::MissingMaterial { id } => write!(f, "missing material resource #{}", id.raw()),
            Self::ResourceIsNotMaterial { id } => {
                write!(f, "resource #{} is not a material", id.raw())
            }
            Self::TooManyMaterials { count } => {
                write!(
                    f,
                    "world uses {count} material slots; maximum is {}",
                    u16::MAX
                )
            }
            Self::TooManySectors { count } => {
                write!(
                    f,
                    "world uses {count} sector records; maximum is {}",
                    u16::MAX
                )
            }
            Self::TooManyWalls { count } => {
                write!(
                    f,
                    "world uses {count} wall records; maximum is {}",
                    u16::MAX
                )
            }
            Self::EncodedWorldTooLarge { bytes } => {
                write!(f, "encoded world payload is too large: {bytes} bytes")
            }
            Self::InvalidWallHeights {
                x,
                z,
                direction,
                heights,
            } => write!(
                f,
                "sector {x},{z} {direction:?} wall has invalid heights {heights:?}"
            ),
            Self::UnsupportedDiagonalWall { x, z, direction } => write!(
                f,
                "sector {x},{z} has a {direction:?} diagonal wall - diagonals aren't supported by the v1 cooker / runtime yet"
            ),
            Self::RoomDimensionExceeded { axis, value, limit } => write!(
                f,
                "room {axis} = {value} exceeds the runtime cap of {limit} sectors"
            ),
            Self::RoomTriangleBudgetExceeded { triangles, limit } => write!(
                f,
                "room would emit {triangles} triangles; cap is {limit}"
            ),
            Self::RoomByteBudgetExceeded { bytes, limit } => write!(
                f,
                "cooked room is {bytes} bytes; cap is {limit}"
            ),
            Self::WallStackExceeded {
                x,
                z,
                direction,
                count,
                limit,
            } => write!(
                f,
                "sector {x},{z} {direction:?} edge has {count} walls; cap is {limit}"
            ),
            Self::DuplicatePhysicalWall {
                x,
                z,
                direction,
                other_x,
                other_z,
                other_direction,
            } => write!(
                f,
                "physical wall claimed twice: ({x},{z}) {direction:?} and ({other_x},{other_z}) {other_direction:?}"
            ),
            Self::HeightNotQuantized {
                x,
                z,
                face,
                value,
                quantum,
            } => write!(
                f,
                "sector {x},{z} {face} has height {value} not aligned to {quantum}-unit quantum"
            ),
            Self::TriangleFaceNotSupported { x, z, face } => write!(
                f,
                "sector {x},{z} {face} is a triangle (dropped corner); .psxw only carries quad faces"
            ),
        }
    }
}

impl std::error::Error for WorldGridCookError {}

/// One material slot used by a cooked world grid.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CookedWorldMaterial {
    /// Runtime slot id.
    pub slot: u16,
    /// Source editor resource id.
    pub source: ResourceId,
    /// Resolved `.psxt` path carried by the material, if any.
    pub psxt_path: Option<String>,
    /// PS1 semi-transparency mode.
    pub blend_mode: PsxBlendMode,
    /// Texture modulation tint.
    pub tint: [u8; 3],
    /// One-pass room-material animation recipe.
    pub animation: MaterialAnimation,
    /// Which side(s) should render.
    pub face_sidedness: MaterialFaceSidedness,
}

impl CookedWorldMaterial {
    fn from_resource(slot: u16, source: ResourceId, material: &MaterialResource) -> Self {
        Self {
            slot,
            source,
            psxt_path: material.psxt_path.clone(),
            blend_mode: material.blend_mode,
            tint: material.tint,
            animation: material.animation,
            face_sidedness: material.sidedness(),
        }
    }
}

/// Cooked horizontal face with resolved runtime material slot.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CookedGridHorizontalTriangle {
    /// `true` when this split triangle is emitted.
    pub visible: bool,
    /// Runtime material slot or [`world::NO_MATERIAL`] when hidden.
    pub material: u16,
    /// Runtime UVs `[NW, NE, SE, SW]` for this split triangle.
    pub uvs: [(u8, u8); 4],
    /// Runtime triangle-local heights in this split triangle's
    /// corner order.
    pub heights: [i32; 3],
    /// Whether collision treats this split triangle as walkable.
    pub walkable: bool,
}

impl CookedGridHorizontalTriangle {
    const HIDDEN: Self = Self {
        visible: false,
        material: world::NO_MATERIAL,
        uvs: world::FLOOR_UVS,
        heights: [0; 3],
        walkable: false,
    };
}

/// Cooked horizontal face with resolved runtime material slot.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CookedGridHorizontalFace {
    /// Corner heights `[NW, NE, SE, SW]`.
    pub heights: [i32; 4],
    /// Diagonal split.
    pub split: GridSplit,
    /// Runtime material slot.
    pub material: u16,
    /// Runtime UVs `[NW, NE, SE, SW]`.
    pub uvs: [(u8, u8); 4],
    /// Baked RGB tint for the face's four vertices.
    pub baked_vertex_rgb: [[u8; 3]; 4],
    /// Whether collision treats this face as walkable.
    pub walkable: bool,
    /// Per-split-triangle render/collision overrides in runtime
    /// triangle order.
    pub triangles: [CookedGridHorizontalTriangle; 2],
}

/// Cooked vertical wall with resolved runtime material slot.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct CookedGridVerticalFace {
    /// Corner heights `[bottom-left, bottom-right, top-right, top-left]`.
    pub heights: [i32; 4],
    /// Runtime material slot.
    pub material: u16,
    /// Runtime wall shape id, see [`psxed_format::world::wall_shape`].
    pub shape: u16,
    /// Runtime UVs `[bottom-left, bottom-right, top-right, top-left]`.
    pub uvs: [(u8, u8); 4],
    /// Baked RGB tint for the wall's four vertices.
    pub baked_vertex_rgb: [[u8; 3]; 4],
    /// Whether collision treats this wall as blocking.
    pub solid: bool,
}

/// Cooked wall lists for one sector.
#[derive(Debug, Clone, Default, PartialEq, Eq)]
pub struct CookedGridWalls {
    /// Walls on the runtime north edge (`.psxw` North = -Z).
    pub north: Vec<CookedGridVerticalFace>,
    /// Walls on the runtime east edge.
    pub east: Vec<CookedGridVerticalFace>,
    /// Walls on the runtime south edge (`.psxw` South = +Z).
    pub south: Vec<CookedGridVerticalFace>,
    /// Walls on the runtime west edge.
    pub west: Vec<CookedGridVerticalFace>,
    /// Diagonal NW-SE walls.
    pub north_west_south_east: Vec<CookedGridVerticalFace>,
    /// Diagonal NE-SW walls.
    pub north_east_south_west: Vec<CookedGridVerticalFace>,
}

impl CookedGridWalls {
    fn get_mut(&mut self, direction: GridDirection) -> &mut Vec<CookedGridVerticalFace> {
        match direction {
            GridDirection::North => &mut self.north,
            GridDirection::East => &mut self.east,
            GridDirection::South => &mut self.south,
            GridDirection::West => &mut self.west,
            GridDirection::NorthWestSouthEast => &mut self.north_west_south_east,
            GridDirection::NorthEastSouthWest => &mut self.north_east_south_west,
        }
    }
}

/// One cooked sector.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CookedGridSector {
    /// Optional floor face.
    pub floor: Option<CookedGridHorizontalFace>,
    /// Optional ceiling face.
    pub ceiling: Option<CookedGridHorizontalFace>,
    /// Sector wall faces.
    pub walls: CookedGridWalls,
}

/// Cooked owned grid-world manifest.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct CookedWorldGrid {
    /// Width in sectors.
    pub width: u16,
    /// Depth in sectors.
    pub depth: u16,
    /// Engine units per sector.
    pub sector_size: i32,
    /// Flat `[x * depth + z]` sector storage.
    pub sectors: Vec<Option<CookedGridSector>>,
    /// Material slots referenced by cooked faces.
    pub materials: Vec<CookedWorldMaterial>,
    /// Room ambient color.
    pub ambient_color: [u8; 3],
    /// Whether baked per-face vertex lighting should be consumed
    /// by the runtime.
    pub static_vertex_lighting: bool,
    /// Whether PS1 depth cue/fog should be enabled.
    pub fog_enabled: bool,
    /// Authored depth-cue far color. Kept in the cook model even
    /// while the current `.psxw` payload only persists the enable flag.
    pub fog_color: [u8; 3],
    /// Authored fog start distance in engine units.
    pub fog_near: i32,
    /// Authored fog end distance in engine units.
    pub fog_far: i32,
}

impl CookedWorldGrid {
    /// Number of sectors that contain cooked geometry.
    pub fn populated_sector_count(&self) -> usize {
        self.sectors.iter().flatten().count()
    }

    /// Number of cooked wall records across all sectors.
    pub fn wall_count(&self) -> u16 {
        self.sectors
            .iter()
            .flatten()
            .map(|sector| {
                sector.walls.north.len()
                    + sector.walls.east.len()
                    + sector.walls.south.len()
                    + sector.walls.west.len()
                    + sector.walls.north_west_south_east.len()
                    + sector.walls.north_east_south_west.len()
            })
            .sum::<usize>() as u16
    }

    /// Encode this cooked grid into the `.psxw` byte layout.
    pub fn to_psxw_bytes(&self) -> Result<Vec<u8>, WorldGridCookError> {
        encode_cooked_world_grid_psxw(self)
    }
}

/// Validate and cook one editor-authored world grid.
pub fn cook_world_grid(
    project: &ProjectDocument,
    grid: &WorldGrid,
) -> Result<CookedWorldGrid, WorldGridCookError> {
    validate_grid_shape(grid)?;
    validate_grid_budget(grid)?;
    validate_no_duplicate_walls(grid)?;
    validate_quantized_heights(grid)?;

    let mut materials = Vec::new();
    let mut material_slots = HashMap::new();
    let mut sectors = Vec::with_capacity(grid.sectors.len());

    for x in 0..grid.width {
        for z in 0..grid.depth {
            let sector = grid
                .sector(x, z)
                .map(|sector| {
                    cook_sector(
                        project,
                        grid,
                        sector,
                        x,
                        z,
                        grid.sector_size,
                        &mut materials,
                        &mut material_slots,
                    )
                })
                .transpose()?
                .flatten();
            sectors.push(sector);
        }
    }

    Ok(CookedWorldGrid {
        width: grid.width,
        depth: grid.depth,
        sector_size: grid.sector_size,
        sectors,
        materials,
        ambient_color: grid.ambient_color,
        static_vertex_lighting: false,
        fog_enabled: grid.fog_enabled,
        fog_color: grid.fog_color,
        fog_near: grid.fog_near,
        fog_far: grid.fog_far,
    })
}

/// Validate, cook, and encode one editor-authored grid as `.psxw` bytes.
pub fn encode_world_grid_psxw(
    project: &ProjectDocument,
    grid: &WorldGrid,
) -> Result<Vec<u8>, WorldGridCookError> {
    cook_world_grid(project, grid)?.to_psxw_bytes()
}

fn cook_sector(
    project: &ProjectDocument,
    grid: &WorldGrid,
    sector: &GridSector,
    x: u16,
    z: u16,
    sector_size: i32,
    materials: &mut Vec<CookedWorldMaterial>,
    material_slots: &mut HashMap<ResourceId, u16>,
) -> Result<Option<CookedGridSector>, WorldGridCookError> {
    if !sector.has_geometry() {
        return Ok(None);
    }

    // The cooker writes one record per face today, but the
    // fields in that record fall into two concerns the runtime
    // already separates via `psx_engine::RoomRender` /
    // `psx_engine::RoomCollision`:
    //
    //   render    -- heights, splits, material slot
    //   collision -- heights, splits, walkable / solid bits
    //
    // Heights and splits feed both views. Materials are render-
    // only (no collision branches on tpage). `walkable` /
    // `solid` are collision-only (no draw call branches on
    // walkability). When v2 lands and the byte format splits
    // render and collision into distinct tables, this function
    // peels into `cook_sector_render` + `cook_sector_collision`
    // -- the call structure is already grouped that way below.

    // -------- render-relevant cook --------
    let floor = sector
        .floor
        .as_ref()
        .map(|face| {
            cook_horizontal_face(
                project,
                face,
                x,
                z,
                WorldGridFaceKind::Floor,
                materials,
                material_slots,
            )
        })
        .transpose()?;
    let ceiling = sector
        .ceiling
        .as_ref()
        .map(|face| {
            cook_horizontal_face(
                project,
                face,
                x,
                z,
                WorldGridFaceKind::Ceiling,
                materials,
                material_slots,
            )
        })
        .transpose()?;
    let walls = cook_walls(
        project,
        &sector.walls,
        &generated_floor_transition_walls(grid, x, z),
        x,
        z,
        sector_size,
        materials,
        material_slots,
    )?;

    // -------- collision-relevant cook --------
    // `walkable` / `solid` are forwarded through the cooked
    // structs by `cook_horizontal_face` / `cook_walls` already
    // -- listed here only so the future v2 split has an obvious
    // landing spot for any extra collision-only data
    // (sector logic offset, vertical floor links, traversal portal slots, …).

    Ok(Some(CookedGridSector {
        floor,
        ceiling,
        walls,
    }))
}

fn cook_horizontal_face(
    project: &ProjectDocument,
    face: &GridHorizontalFace,
    x: u16,
    z: u16,
    kind: WorldGridFaceKind,
    materials: &mut Vec<CookedWorldMaterial>,
    material_slots: &mut HashMap<ResourceId, u16>,
) -> Result<CookedGridHorizontalFace, WorldGridCookError> {
    let split = runtime_horizontal_split(face.split);
    let triangles =
        cook_horizontal_triangles(project, face, x, z, kind, materials, material_slots)?;
    let fallback = triangles
        .iter()
        .copied()
        .find(|triangle| triangle.visible)
        .unwrap_or(CookedGridHorizontalTriangle::HIDDEN);
    Ok(CookedGridHorizontalFace {
        heights: runtime_horizontal_heights(face.heights),
        split,
        material: fallback.material,
        uvs: fallback.uvs,
        baked_vertex_rgb: DEFAULT_BAKED_VERTEX_RGB,
        walkable: triangles
            .iter()
            .any(|triangle| triangle.visible && triangle.walkable),
        triangles,
    })
}

fn cook_horizontal_triangles(
    project: &ProjectDocument,
    face: &GridHorizontalFace,
    x: u16,
    z: u16,
    kind: WorldGridFaceKind,
    materials: &mut Vec<CookedWorldMaterial>,
    material_slots: &mut HashMap<ResourceId, u16>,
) -> Result<[CookedGridHorizontalTriangle; 2], WorldGridCookError> {
    let mut triangles = [CookedGridHorizontalTriangle::HIDDEN; 2];
    if let Some(parent_material) = face.material {
        let parent_is_visible = (0..2).any(|editor_index| {
            editor_horizontal_triangle_visible(face, editor_index)
                && face.triangle_material(editor_index) == Some(parent_material)
        });
        if parent_is_visible {
            let _ = material_slot(
                project,
                Some(parent_material),
                x,
                z,
                kind,
                materials,
                material_slots,
            )?;
        }
    }
    for editor_index in 0..2 {
        if !editor_horizontal_triangle_visible(face, editor_index) {
            continue;
        }
        let runtime_index = runtime_horizontal_triangle_index(editor_index);
        let material = material_slot(
            project,
            face.triangle_material(editor_index),
            x,
            z,
            kind,
            materials,
            material_slots,
        )?;
        triangles[runtime_index] = CookedGridHorizontalTriangle {
            visible: true,
            material,
            uvs: runtime_horizontal_uvs(
                face.triangle_uv(editor_index)
                    .apply_to_quad(world::FLOOR_UVS),
            ),
            heights: runtime_horizontal_triangle_heights(face, editor_index),
            walkable: face.triangle_walkable(editor_index),
        };
    }
    Ok(triangles)
}

fn runtime_horizontal_triangle_heights(face: &GridHorizontalFace, editor_index: usize) -> [i32; 3] {
    let runtime_split = runtime_horizontal_split(face.split);
    let runtime_index = runtime_horizontal_triangle_index(editor_index);
    let editor_corners = crate::horizontal_triangle_corners(face.split, editor_index);
    let editor_heights = face.triangle_heights(editor_index);
    let mut editor_quad = face.heights;
    for (corner, height) in editor_corners.into_iter().zip(editor_heights) {
        editor_quad[corner.idx()] = height;
    }
    let runtime_quad = runtime_horizontal_heights(editor_quad);
    let runtime_corners = crate::horizontal_triangle_corners(runtime_split, runtime_index);
    [
        runtime_quad[runtime_corners[0].idx()],
        runtime_quad[runtime_corners[1].idx()],
        runtime_quad[runtime_corners[2].idx()],
    ]
}

const fn runtime_horizontal_triangle_index(editor_index: usize) -> usize {
    if editor_index == 0 {
        1
    } else {
        0
    }
}

fn editor_horizontal_triangle_visible(face: &GridHorizontalFace, index: usize) -> bool {
    let Some(dropped) = face.dropped_corner else {
        return true;
    };
    !crate::horizontal_triangle_contains_corner(face.split, index, dropped)
}

fn cook_walls(
    project: &ProjectDocument,
    walls: &GridWalls,
    generated_walls: &GridWalls,
    x: u16,
    z: u16,
    sector_size: i32,
    materials: &mut Vec<CookedWorldMaterial>,
    material_slots: &mut HashMap<ResourceId, u16>,
) -> Result<CookedGridWalls, WorldGridCookError> {
    let mut cooked = CookedGridWalls::default();
    // Duplicate physical walls (east of
    // (x,z) and west of (x+1,z) describe the same face) are
    // already rejected upstream by `validate_no_duplicate_walls`
    // -- by the time we reach this loop the grid is guaranteed
    // to claim each physical edge from at most one side.
    for direction in GridDirection::ALL {
        for wall in walls
            .get(direction)
            .iter()
            .chain(generated_walls.get(direction).iter())
        {
            validate_wall_heights(wall, x, z, direction)?;
            let material = material_slot(
                project,
                wall.material,
                x,
                z,
                WorldGridFaceKind::Wall(direction),
                materials,
                material_slots,
            )?;
            let runtime_direction = runtime_wall_direction(direction);
            for segment in wall.split_into_autotile_segments(sector_size) {
                validate_wall_heights(&segment, x, z, direction)?;
                cooked
                    .get_mut(runtime_direction)
                    .push(CookedGridVerticalFace {
                        heights: runtime_wall_heights(segment.heights),
                        material,
                        shape: runtime_wall_shape(segment.dropped_corner),
                        uvs: runtime_wall_uvs(segment.uv.apply_to_quad(world::WALL_UVS)),
                        baked_vertex_rgb: DEFAULT_BAKED_VERTEX_RGB,
                        solid: segment.solid,
                    });
            }
        }
    }
    Ok(cooked)
}

fn generated_floor_transition_walls(grid: &WorldGrid, x: u16, z: u16) -> GridWalls {
    let mut walls = GridWalls::default();
    for direction in [GridDirection::East, GridDirection::North] {
        if let Some(wall) = grid.floor_transition_wall_for_edge(x, z, direction) {
            walls.get_mut(direction).push(wall);
        }
    }
    walls
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{
        Corner, GridTriangleMaterialOverride, GridUvRotation, GridUvTransform, MaterialVersionId,
        NodeKind, ResourceData, WallCorner,
    };

    fn starter_grid(project: &ProjectDocument) -> WorldGrid {
        let template = project
            .active_scene()
            .nodes()
            .iter()
            .find_map(|node| match &node.kind {
                NodeKind::Room { grid } => Some(grid.clone()),
                _ => None,
            })
            .expect("starter project should contain a room");
        let material = project
            .resources
            .iter()
            .find_map(|resource| match &resource.data {
                ResourceData::Material(_) => Some(resource.id),
                _ => None,
            });
        let mut grid = WorldGrid::stone_room(2, 3, template.sector_size, material, material);
        grid.ambient_color = template.ambient_color;
        grid.fog_enabled = template.fog_enabled;
        grid.fog_color = template.fog_color;
        grid.fog_near = template.fog_near;
        grid.fog_far = template.fog_far;
        grid.atmosphere_enabled = template.atmosphere_enabled;
        grid.atmosphere_color = template.atmosphere_color;
        grid.atmosphere_density = template.atmosphere_density;
        grid.atmosphere_fall_speed_q4 = template.atmosphere_fall_speed_q4;
        grid.atmosphere_wind_speed_q4 = template.atmosphere_wind_speed_q4;
        grid
    }

    fn first_floor_material(grid: &WorldGrid) -> ResourceId {
        grid.sectors
            .iter()
            .flatten()
            .find_map(|sector| sector.floor.as_ref()?.material)
            .expect("starter floor has material")
    }

    fn texture_named(project: &ProjectDocument, suffix: &str) -> String {
        project
            .resources
            .iter()
            .find_map(|resource| match &resource.data {
                ResourceData::Material(material) => material
                    .psxt_path
                    .as_ref()
                    .filter(|path| path.ends_with(suffix))
                    .cloned(),
                _ => None,
            })
            .expect("starter material texture exists")
    }

    fn material_for_texture(
        project: &mut ProjectDocument,
        name: &str,
        psxt_path: String,
    ) -> ResourceId {
        project.add_resource(
            name,
            ResourceData::Material(crate::MaterialResource::opaque(Some(psxt_path))),
        )
    }

    fn minimal_material_project() -> (ProjectDocument, ResourceId) {
        let mut project = ProjectDocument::new("world-cook-test");
        let material = material_for_texture(&mut project, "test material", "test.psxt".into());
        (project, material)
    }

    fn first_populated_cooked_sector(cooked: &CookedWorldGrid) -> &CookedGridSector {
        cooked
            .sectors
            .iter()
            .flatten()
            .next()
            .expect("starter has populated sector")
    }

    fn authored_geometry_sector_count(grid: &WorldGrid) -> usize {
        grid.sectors
            .iter()
            .flatten()
            .filter(|sector| sector.has_geometry())
            .count()
    }

    fn cooked_wall_count(sector: &CookedGridSector) -> usize {
        sector.walls.north.len()
            + sector.walls.east.len()
            + sector.walls.south.len()
            + sector.walls.west.len()
            + sector.walls.north_west_south_east.len()
            + sector.walls.north_east_south_west.len()
    }

    fn max_uv_v_span(uvs: [(u8, u8); 4]) -> u8 {
        let min_v = uvs.iter().map(|(_, v)| *v).min().unwrap();
        let max_v = uvs.iter().map(|(_, v)| *v).max().unwrap();
        max_v - min_v
    }

    #[test]
    fn cooks_starter_grid_to_material_slots() {
        let project = ProjectDocument::starter();
        let grid = starter_grid(&project);

        let cooked = cook_world_grid(&project, &grid).unwrap();

        assert_eq!(cooked.width, grid.width);
        assert_eq!(cooked.depth, grid.depth);
        assert_eq!(cooked.sector_size, grid.sector_size);
        assert_eq!(
            cooked.populated_sector_count(),
            authored_geometry_sector_count(&grid)
        );
        assert_eq!(cooked.materials.len(), 1);
        for (idx, material) in cooked.materials.iter().enumerate() {
            assert_eq!(material.slot, idx as u16);
        }
        let first_sector = first_populated_cooked_sector(&cooked);
        assert!(first_sector.floor.is_some());
        assert_eq!(first_sector.floor.unwrap().material, 0);
    }

    #[test]
    fn cook_flips_horizontal_faces_to_runtime_z_convention() {
        let project = ProjectDocument::starter();
        let material = first_floor_material(&starter_grid(&project));
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.set_floor(0, 0, 0, Some(material));
        let floor = grid
            .sector_mut(0, 0)
            .and_then(|sector| sector.floor.as_mut())
            .expect("floor exists");
        floor.heights = [64, 128, 192, 256];
        floor.split = GridSplit::NorthWestSouthEast;

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let cooked_floor = cooked.sectors[0].as_ref().unwrap().floor.unwrap();

        assert_eq!(cooked_floor.heights, [256, 192, 128, 64]);
        assert_eq!(cooked_floor.split, GridSplit::NorthEastSouthWest);
    }

    #[test]
    fn cook_bakes_horizontal_uv_transform_to_runtime_uvs() {
        let project = ProjectDocument::starter();
        let material = first_floor_material(&starter_grid(&project));
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.set_floor(0, 0, 0, Some(material));
        let floor_uv = GridUvTransform {
            offset: [3, -2],
            span: [0, 0],
            rotation: GridUvRotation::Deg90,
            flip_u: false,
            flip_v: true,
        };
        grid.sector_mut(0, 0)
            .and_then(|sector| sector.floor.as_mut())
            .expect("floor exists")
            .uv = floor_uv;

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let cooked_floor = cooked.sectors[0].as_ref().unwrap().floor.unwrap();
        let bytes = encode_world_grid_psxw(&project, &grid).unwrap();
        let world = psx_asset::World::from_bytes(&bytes).expect("psxw parses");

        assert_eq!(
            cooked_floor.uvs,
            runtime_horizontal_uvs(floor_uv.apply_to_quad(world::FLOOR_UVS))
        );
        assert_eq!(
            world.sector(0, 0).unwrap().floor_uvs().corners(),
            cooked_floor.uvs
        );
    }

    #[test]
    fn cook_flips_cardinal_walls_to_runtime_convention() {
        let project = ProjectDocument::starter();
        let material = first_floor_material(&starter_grid(&project));
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.add_wall(
            0,
            0,
            GridDirection::North,
            0,
            world::SECTOR_SIZE,
            Some(material),
        );
        let wall = grid
            .sector_mut(0, 0)
            .and_then(|sector| sector.walls.get_mut(GridDirection::North).first_mut())
            .expect("north wall exists");
        wall.heights = [64, 128, 192, 256];

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let cooked_walls = &cooked.sectors[0].as_ref().unwrap().walls;

        assert!(cooked_walls.north.is_empty());
        assert_eq!(cooked_walls.south[0].heights, [128, 64, 256, 192]);
    }

    #[test]
    fn cook_bakes_wall_uv_transform_to_runtime_uvs() {
        let project = ProjectDocument::starter();
        let material = first_floor_material(&starter_grid(&project));
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.add_wall(
            0,
            0,
            GridDirection::North,
            0,
            world::SECTOR_SIZE,
            Some(material),
        );
        let wall_uv = GridUvTransform {
            offset: [-5, 7],
            span: [0, 0],
            rotation: GridUvRotation::Deg180,
            flip_u: true,
            flip_v: false,
        };
        grid.sector_mut(0, 0)
            .and_then(|sector| sector.walls.get_mut(GridDirection::North).first_mut())
            .expect("north wall exists")
            .uv = wall_uv;

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let cooked_wall = cooked.sectors[0]
            .as_ref()
            .unwrap()
            .walls
            .south
            .first()
            .copied()
            .expect("north editor wall cooks to runtime south");
        let bytes = encode_world_grid_psxw(&project, &grid).unwrap();
        let world = psx_asset::World::from_bytes(&bytes).expect("psxw parses");
        let sector = world.sector(0, 0).unwrap();
        let parsed_wall = world.sector_wall(sector, 0).unwrap();

        assert_eq!(
            cooked_wall.uvs,
            runtime_wall_uvs(wall_uv.apply_to_quad(world::WALL_UVS))
        );
        assert_eq!(parsed_wall.uvs().corners(), cooked_wall.uvs);
    }

    #[test]
    fn cook_keeps_default_tall_wall_uvs_matching_editor_preview() {
        let project = ProjectDocument::starter();
        let material = first_floor_material(&starter_grid(&project));
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.add_wall(
            0,
            0,
            GridDirection::North,
            0,
            world::SECTOR_SIZE * 2,
            Some(material),
        );

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let cooked_sector = cooked.sectors[0].as_ref().unwrap();
        let bytes = encode_world_grid_psxw(&project, &grid).unwrap();
        let parsed_world = psx_asset::World::from_bytes(&bytes).expect("psxw parses");
        let parsed_sector = parsed_world.sector(0, 0).unwrap();
        let parsed_wall = parsed_world.sector_wall(parsed_sector, 0).unwrap();

        assert_eq!(cooked_wall_count(cooked_sector), 1);
        assert_eq!(parsed_sector.wall_count(), 1);
        assert_eq!(
            max_uv_v_span(cooked_sector.walls.south[0].uvs),
            world::TILE_UV
        );
        assert_eq!(max_uv_v_span(parsed_wall.uvs().corners()), world::TILE_UV);
    }

    #[test]
    fn cook_splits_explicit_autotiled_wall_only_when_uv_exceeds_packet_range() {
        let project = ProjectDocument::starter();
        let material = first_floor_material(&starter_grid(&project));
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.add_wall(
            0,
            0,
            GridDirection::North,
            0,
            world::SECTOR_SIZE * 5,
            Some(material),
        );
        grid.sector_mut(0, 0)
            .and_then(|sector| sector.walls.get_mut(GridDirection::North).first_mut())
            .expect("north wall exists")
            .autotile_uv(world::SECTOR_SIZE);

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let cooked_sector = cooked.sectors[0].as_ref().unwrap();
        let bytes = encode_world_grid_psxw(&project, &grid).unwrap();
        let parsed_world = psx_asset::World::from_bytes(&bytes).expect("psxw parses");
        let parsed_sector = parsed_world.sector(0, 0).unwrap();

        assert_eq!(cooked_wall_count(cooked_sector), 5);
        assert_eq!(parsed_sector.wall_count(), 5);
        for wall in &cooked_sector.walls.south {
            assert!(max_uv_v_span(wall.uvs) <= world::TILE_UV);
        }
        for index in 0..5 {
            let parsed_wall = parsed_world.sector_wall(parsed_sector, index).unwrap();
            assert!(max_uv_v_span(parsed_wall.uvs().corners()) <= world::TILE_UV);
        }
    }

    #[test]
    fn cooks_quantized_non_default_sector_size() {
        let project = ProjectDocument::starter();
        let mut grid = starter_grid(&project);
        grid.rescale_sector_size(1536);

        let cooked = cook_world_grid(&project, &grid).unwrap();

        assert_eq!(cooked.sector_size, 1536);
    }

    #[test]
    fn rejects_non_quantized_sector_size() {
        let project = ProjectDocument::starter();
        let mut grid = starter_grid(&project);
        grid.sector_size = 513;

        assert_eq!(
            cook_world_grid(&project, &grid).unwrap_err(),
            WorldGridCookError::UnsupportedSectorSize {
                expected: WORLD_SECTOR_SIZE_QUANTUM,
                actual: 513,
            }
        );
    }

    #[test]
    fn rejects_bad_sector_storage_len() {
        let project = ProjectDocument::starter();
        let mut grid = WorldGrid::empty(2, 2, world::SECTOR_SIZE);
        grid.sectors.pop();

        assert_eq!(
            cook_world_grid(&project, &grid).unwrap_err(),
            WorldGridCookError::SectorStorageLenMismatch {
                expected: 4,
                actual: 3,
            }
        );
    }

    #[test]
    fn rejects_unassigned_surface_material() {
        let project = ProjectDocument::starter();
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.set_floor(0, 0, 0, None);

        assert_eq!(
            cook_world_grid(&project, &grid).unwrap_err(),
            WorldGridCookError::UnassignedMaterial {
                x: 0,
                z: 0,
                face: WorldGridFaceKind::Floor,
            }
        );
    }

    #[test]
    fn rejects_non_material_resources() {
        let project = ProjectDocument::starter();
        let model = project
            .resources
            .iter()
            .find_map(|resource| match resource.data {
                ResourceData::Model(_) => Some(resource.id),
                _ => None,
            })
            .expect("starter project should contain a model");
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.set_floor(0, 0, 0, Some(model));

        assert_eq!(
            cook_world_grid(&project, &grid).unwrap_err(),
            WorldGridCookError::ResourceIsNotMaterial { id: model }
        );
    }

    #[test]
    fn strips_empty_authored_sectors() {
        let project = ProjectDocument::starter();
        let grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);

        let cooked = cook_world_grid(&project, &grid).unwrap();

        assert_eq!(cooked.sectors, vec![None]);
        assert!(cooked.materials.is_empty());
    }

    #[test]
    fn cooked_starter_round_trips_through_psx_asset() {
        // End-to-end: cook the starter grid, parse the .psxw bytes
        // through `psx_asset::World`, and verify the runtime view
        // decodes the same dimensions / sector / wall counts the
        // cooker reported. Regresses the v1 byte layout against
        // both producer and consumer in one assertion.
        let mut project = ProjectDocument::starter();
        let floor_texture = texture_named(&project, "block_1a.psxt");
        let wall_texture = texture_named(&project, "brick_1a.psxt");
        let floor = material_for_texture(&mut project, "Floor Slot", floor_texture);
        let wall = material_for_texture(&mut project, "Wall Slot", wall_texture);
        let grid = WorldGrid::stone_room(2, 2, 1024, Some(floor), Some(wall));
        let cooked = cook_world_grid(&project, &grid).unwrap();
        let bytes = encode_world_grid_psxw(&project, &grid).unwrap();

        let world = psx_asset::World::from_bytes(&bytes).expect("psxw parses");
        assert_eq!(world.width(), cooked.width);
        assert_eq!(world.depth(), cooked.depth);
        assert_eq!(world.sector_size(), cooked.sector_size);
        assert_eq!(world.material_count() as usize, cooked.materials.len());
        assert_eq!(world.ambient_color(), grid.ambient_color);

        // Sector (0,0) -- the starter has a floor + perimeter walls
        // in its first populated cell, so this exercises both
        // decoded paths without assuming a fixed starter shape.
        let (sx, sz, _) = cooked
            .sectors
            .iter()
            .enumerate()
            .find_map(|(index, sector)| {
                let sector = sector.as_ref()?;
                Some((
                    (index / cooked.depth as usize) as u16,
                    (index % cooked.depth as usize) as u16,
                    sector,
                ))
            })
            .expect("starter has populated sector");
        let sector = world.sector(sx, sz).expect("starter sector populated");
        assert!(sector.has_floor());
        assert!(sector.wall_count() > 0);
    }

    #[test]
    fn starter_cook_pins_first_used_material_slots() {
        // The cooker assigns slots in first-use order while iterating
        // sectors `[x * depth + z]`. If a future reshape flips that
        // order, the runtime package contract changes.
        let mut project = ProjectDocument::starter();
        let floor_texture = texture_named(&project, "block_1a.psxt");
        let wall_texture = texture_named(&project, "brick_1a.psxt");
        let floor = material_for_texture(&mut project, "Floor Slot", floor_texture);
        let wall = material_for_texture(&mut project, "Wall Slot", wall_texture);
        let grid = WorldGrid::stone_room(2, 2, 1024, Some(floor), Some(wall));
        let cooked = cook_world_grid(&project, &grid).unwrap();

        assert_eq!(cooked.materials.len(), 2);

        let psxt_path_for_slot = |slot: usize| -> String {
            cooked.materials[slot]
                .psxt_path
                .clone()
                .expect("starter material has a texture")
        };

        assert!(psxt_path_for_slot(0).ends_with("block_1a.psxt"));
        assert!(psxt_path_for_slot(1).ends_with("brick_1a.psxt"));
    }

    #[test]
    fn world_cook_uses_only_the_active_material_version() {
        let mut project = ProjectDocument::new("versioned cook");
        let mut material = MaterialResource::opaque(Some("original.psxt".to_string()));
        material.tint = [32, 48, 64];
        let material_id = project.add_resource("Stone", ResourceData::Material(material));
        let grid = WorldGrid::stone_room(1, 1, 1024, Some(material_id), Some(material_id));

        let ResourceData::Material(material) = &mut project.resource_mut(material_id).unwrap().data
        else {
            panic!("stone is a material");
        };
        let llm_version = material.create_version("LLM");
        material.psxt_path = Some("llm.psxt".to_string());
        material.tint = [129, 37, 181];

        let cooked = cook_world_grid(&project, &grid).unwrap();
        assert_eq!(cooked.materials.len(), 1);
        assert_eq!(cooked.materials[0].psxt_path.as_deref(), Some("llm.psxt"));
        assert_eq!(cooked.materials[0].tint, [129, 37, 181]);

        let ResourceData::Material(material) = &mut project.resource_mut(material_id).unwrap().data
        else {
            unreachable!();
        };
        assert_eq!(material.active_version_id, llm_version);
        assert!(material.activate_version(MaterialVersionId::ORIGINAL));
        let cooked = cook_world_grid(&project, &grid).unwrap();
        assert_eq!(
            cooked.materials[0].psxt_path.as_deref(),
            Some("original.psxt")
        );
        assert_eq!(cooked.materials[0].tint, [32, 48, 64]);
    }

    #[test]
    fn rejects_oversized_room_dimensions() {
        let project = ProjectDocument::starter();
        let grid = WorldGrid::empty(MAX_ROOM_WIDTH + 1, 4, world::SECTOR_SIZE);
        match cook_world_grid(&project, &grid) {
            Err(WorldGridCookError::RoomDimensionExceeded { axis, value, limit }) => {
                assert_eq!(axis, 'X');
                assert_eq!(value, MAX_ROOM_WIDTH + 1);
                assert_eq!(limit, MAX_ROOM_WIDTH);
            }
            other => panic!("expected RoomDimensionExceeded, got {other:?}"),
        }
    }

    #[test]
    fn rejects_excessive_wall_stacks() {
        let project = ProjectDocument::starter();
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        for _ in 0..(MAX_WALL_STACK + 1) {
            grid.add_wall(0, 0, GridDirection::North, 0, world::SECTOR_SIZE, None);
        }
        match cook_world_grid(&project, &grid) {
            Err(WorldGridCookError::WallStackExceeded {
                x,
                z,
                direction,
                count,
                limit,
            }) => {
                assert_eq!((x, z), (0, 0));
                assert_eq!(direction, GridDirection::North);
                assert_eq!(count, MAX_WALL_STACK + 1);
                assert_eq!(limit, MAX_WALL_STACK);
            }
            other => panic!("expected WallStackExceeded, got {other:?}"),
        }
    }

    #[test]
    fn rejects_duplicate_physical_walls() {
        // East(0, 0) and West(1, 0) describe the same physical
        // wall. Authoring both must surface a clear cook error.
        let project = ProjectDocument::starter();
        let mut grid = WorldGrid::empty(2, 1, world::SECTOR_SIZE);
        grid.add_wall(0, 0, GridDirection::East, 0, world::SECTOR_SIZE, None);
        grid.add_wall(1, 0, GridDirection::West, 0, world::SECTOR_SIZE, None);
        match cook_world_grid(&project, &grid) {
            Err(WorldGridCookError::DuplicatePhysicalWall {
                x,
                z,
                direction,
                other_x,
                other_z,
                other_direction,
            }) => {
                // The cooker walks (x, z) major; East(0,0) is
                // claimed first, so the duplicate is West(1,0).
                assert_eq!((x, z, direction), (1, 0, GridDirection::West));
                assert_eq!(
                    (other_x, other_z, other_direction),
                    (0, 0, GridDirection::East)
                );
            }
            other => panic!("expected DuplicatePhysicalWall, got {other:?}"),
        }
    }

    #[test]
    fn rejects_duplicate_physical_walls_on_editor_north_south_edges() {
        // Editor convention is North=+Z and South=-Z. These two
        // authored records both claim the edge between rows 0 and 1.
        let project = ProjectDocument::starter();
        let mut grid = WorldGrid::empty(1, 2, world::SECTOR_SIZE);
        grid.add_wall(0, 0, GridDirection::North, 0, world::SECTOR_SIZE, None);
        grid.add_wall(0, 1, GridDirection::South, 0, world::SECTOR_SIZE, None);

        match cook_world_grid(&project, &grid) {
            Err(WorldGridCookError::DuplicatePhysicalWall {
                x,
                z,
                direction,
                other_x,
                other_z,
                other_direction,
            }) => {
                assert_eq!((x, z, direction), (0, 1, GridDirection::South));
                assert_eq!(
                    (other_x, other_z, other_direction),
                    (0, 0, GridDirection::North)
                );
            }
            other => panic!("expected DuplicatePhysicalWall, got {other:?}"),
        }
    }

    #[test]
    fn rejects_non_quantized_heights() {
        // Floor with one corner off the quantum grid. Using
        // `set_floor` with a snap-aligned value, then mutating
        // a single corner directly so the test bypasses the
        // editor's drag snap (which is the runtime path the
        // cooker validator catches).
        let project = ProjectDocument::starter();
        let mut grid = WorldGrid::stone_room(1, 1, world::SECTOR_SIZE, None, None);
        if let Some(sector) = grid.sector_mut(0, 0) {
            if let Some(floor) = sector.floor.as_mut() {
                floor.heights[0] = 17; // Not a multiple of HEIGHT_QUANTUM.
            }
        }
        match cook_world_grid(&project, &grid) {
            Err(WorldGridCookError::HeightNotQuantized {
                x,
                z,
                face,
                value,
                quantum,
            }) => {
                assert_eq!((x, z), (0, 0));
                assert_eq!(face, WorldGridFaceKind::Floor);
                assert_eq!(value, 17);
                assert_eq!(quantum, HEIGHT_QUANTUM);
            }
            other => panic!("expected HeightNotQuantized, got {other:?}"),
        }
    }

    #[test]
    fn cooks_triangle_floor_as_single_runtime_triangle() {
        // Dropped floor corners cook through the v4 horizontal
        // override table: the sector still has a floor, but only
        // the surviving split triangle is visible at runtime.
        let project = ProjectDocument::starter();
        let material = first_floor_material(&starter_grid(&project));
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.set_floor(0, 0, 0, Some(material));
        if let Some(sector) = grid.sector_mut(0, 0) {
            if let Some(floor) = sector.floor.as_mut() {
                floor.drop_corner(Corner::NW);
            }
        }

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let floor = cooked.sectors[0].as_ref().unwrap().floor.unwrap();
        assert_eq!(
            floor
                .triangles
                .iter()
                .filter(|triangle| triangle.visible)
                .count(),
            1
        );

        let bytes = encode_world_grid_psxw(&project, &grid).unwrap();
        let parsed_world = psx_asset::World::from_bytes(&bytes).expect("psxw parses");
        let sector = parsed_world.sector(0, 0).unwrap();
        assert_eq!(parsed_world.horizontal_override_count(), 1);
        assert!(sector.has_floor());
        assert!(sector.floor_triangle_present(0));
        assert!(!sector.floor_triangle_present(1));
    }

    #[test]
    fn cooks_horizontal_triangle_material_uv_and_walkable_overrides() {
        let mut project = ProjectDocument::starter();
        let base = first_floor_material(&starter_grid(&project));
        let floor_texture = texture_named(&project, "block_1a.psxt");
        let override_material = material_for_texture(&mut project, "Triangle Slot", floor_texture);
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.set_floor(0, 0, 0, Some(base));
        let uv = GridUvTransform {
            offset: [7, -3],
            span: [0, 0],
            rotation: GridUvRotation::Deg90,
            flip_u: true,
            flip_v: false,
        };
        let floor = grid
            .sector_mut(0, 0)
            .and_then(|sector| sector.floor.as_mut())
            .expect("floor exists");
        let triangle = floor.triangle_override_mut(0);
        triangle.material = Some(GridTriangleMaterialOverride::Resource(override_material));
        triangle.uv = Some(uv);
        triangle.walkable = Some(false);

        let cooked = cook_world_grid(&project, &grid).unwrap();
        assert_eq!(cooked.materials.len(), 2);

        let bytes = encode_world_grid_psxw(&project, &grid).unwrap();
        let parsed_world = psx_asset::World::from_bytes(&bytes).expect("psxw parses");
        let sector = parsed_world.sector(0, 0).unwrap();
        assert_eq!(parsed_world.horizontal_override_count(), 1);
        assert_eq!(sector.floor_triangle_material(0), Some(0));
        assert_eq!(sector.floor_triangle_material(1), Some(1));
        assert!(sector.floor_triangle_walkable(0));
        assert!(!sector.floor_triangle_walkable(1));
        assert_eq!(
            sector.floor_triangle_uvs(1).corners(),
            runtime_horizontal_uvs(uv.apply_to_quad(world::FLOOR_UVS))
        );
    }

    #[test]
    fn cooks_horizontal_triangle_height_overrides() {
        let (project, material) = minimal_material_project();
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.set_floor(0, 0, 0, Some(material));
        let floor = grid
            .sector_mut(0, 0)
            .and_then(|sector| sector.floor.as_mut())
            .expect("floor exists");
        floor.heights = [0, 0, 0, 0];
        floor.split = GridSplit::NorthWestSouthEast;
        floor.triangle_override_mut(0).heights = Some([64, 128, 192]);

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let cooked_floor = cooked.sectors[0].as_ref().unwrap().floor.unwrap();
        assert_eq!(cooked_floor.triangles[1].heights, [192, 128, 64]);
        assert_eq!(cooked_floor.triangles[0].heights, [0, 0, 0]);

        let bytes = encode_world_grid_psxw(&project, &grid).unwrap();
        let parsed_world = psx_asset::World::from_bytes(&bytes).expect("psxw parses");
        let sector = parsed_world.sector(0, 0).unwrap();
        assert_eq!(parsed_world.horizontal_override_count(), 1);
        assert_eq!(sector.floor_triangle_heights(1), [192, 128, 64]);
        assert_eq!(sector.floor_triangle_heights(0), [0, 0, 0]);
    }

    #[test]
    fn cooks_triangle_wall_shape() {
        let project = ProjectDocument::starter();
        let material = first_floor_material(&starter_grid(&project));
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.add_wall(
            0,
            0,
            GridDirection::North,
            0,
            world::SECTOR_SIZE,
            Some(material),
        );
        if let Some(sector) = grid.sector_mut(0, 0) {
            let walls = sector.walls.get_mut(GridDirection::North);
            if let Some(wall) = walls.first_mut() {
                wall.drop_corner(WallCorner::TL);
            }
        }

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let cooked_walls = &cooked.sectors[0].as_ref().unwrap().walls;
        assert!(cooked_walls.north.is_empty());
        assert_eq!(
            cooked_walls.south[0].shape,
            world::wall_shape::DROP_TOP_RIGHT
        );

        let bytes = encode_world_grid_psxw(&project, &grid).unwrap();
        let parsed_world = psx_asset::World::from_bytes(&bytes).expect("psxw parses");
        let sector = parsed_world.sector(0, 0).unwrap();
        let wall = parsed_world.sector_wall(sector, 0).unwrap();
        assert_eq!(wall.shape(), world::wall_shape::DROP_TOP_RIGHT);
    }

    #[test]
    fn cooks_floor_height_transition_wall_between_mismatched_neighbours() {
        let project = ProjectDocument::starter();
        let material = first_floor_material(&starter_grid(&project));
        let mut grid = WorldGrid::empty(2, 1, world::SECTOR_SIZE);
        grid.set_floor(0, 0, 0, Some(material));
        grid.set_floor(1, 0, 512, Some(material));

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let first_sector = cooked.sectors[0].as_ref().unwrap();
        let second_sector = cooked.sectors[1].as_ref().unwrap();

        assert_eq!(first_sector.walls.east.len(), 1);
        assert!(second_sector.walls.west.is_empty());
        assert_eq!(first_sector.walls.east[0].heights, [0, 0, 512, 512]);
    }

    #[test]
    fn cook_flips_diagonal_walls_to_runtime_convention() {
        let project = ProjectDocument::starter();
        let material = first_floor_material(&starter_grid(&project));
        let mut grid = WorldGrid::empty(1, 1, world::SECTOR_SIZE);
        grid.add_wall(
            0,
            0,
            GridDirection::NorthWestSouthEast,
            0,
            world::SECTOR_SIZE,
            Some(material),
        );
        let wall = grid
            .sector_mut(0, 0)
            .and_then(|sector| {
                sector
                    .walls
                    .get_mut(GridDirection::NorthWestSouthEast)
                    .first_mut()
            })
            .expect("diagonal wall exists");
        wall.heights = [64, 128, 192, 256];

        let cooked = cook_world_grid(&project, &grid).unwrap();
        let cooked_walls = &cooked.sectors[0].as_ref().unwrap().walls;

        assert!(cooked_walls.north_west_south_east.is_empty());
        assert_eq!(
            cooked_walls.north_east_south_west[0].heights,
            [128, 64, 256, 192]
        );
    }

    #[test]
    fn encodes_starter_grid_as_psxw_blob() {
        let project = ProjectDocument::starter();
        let grid = starter_grid(&project);
        let cooked = cook_world_grid(&project, &grid).unwrap();

        let bytes = encode_world_grid_psxw(&project, &grid).unwrap();

        assert_eq!(&bytes[0..4], &world::MAGIC);
        assert_eq!(u16::from_le_bytes([bytes[4], bytes[5]]), world::VERSION);
        let payload_len = u32::from_le_bytes([bytes[8], bytes[9], bytes[10], bytes[11]]);
        assert_eq!(
            payload_len as usize,
            bytes.len() - psxed_format::AssetHeader::SIZE
        );

        let header = psxed_format::AssetHeader::SIZE;
        assert_eq!(
            u16::from_le_bytes([bytes[header], bytes[header + 1]]),
            grid.width
        );
        assert_eq!(
            u16::from_le_bytes([bytes[header + 2], bytes[header + 3]]),
            grid.depth
        );
        assert_eq!(
            i32::from_le_bytes([
                bytes[header + 4],
                bytes[header + 5],
                bytes[header + 6],
                bytes[header + 7],
            ]),
            grid.sector_size
        );
        assert_eq!(
            u16::from_le_bytes([bytes[header + 8], bytes[header + 9]]),
            grid.width * grid.depth
        );
        assert_eq!(
            u16::from_le_bytes([bytes[header + 10], bytes[header + 11]]),
            cooked.materials.len() as u16
        );
        assert_eq!(
            u16::from_le_bytes([bytes[header + 12], bytes[header + 13]]),
            cooked.wall_count()
        );
        assert_eq!(
            [bytes[header + 14], bytes[header + 15], bytes[header + 16]],
            grid.ambient_color
        );

        let first_sector_index = cooked
            .sectors
            .iter()
            .position(|sector| sector.is_some())
            .expect("starter has populated sector");
        let sector =
            header + world::WorldHeader::SIZE + first_sector_index * world::SectorRecord::SIZE;
        assert_eq!(
            bytes[sector],
            world::sector_flags::HAS_FLOOR | world::sector_flags::FLOOR_WALKABLE
        );
        assert_eq!(
            u16::from_le_bytes([bytes[sector + 4], bytes[sector + 5]]),
            0
        );
        assert_eq!(
            u16::from_le_bytes([bytes[sector + 10], bytes[sector + 11]]),
            cooked_wall_count(first_populated_cooked_sector(&cooked)) as u16
        );
    }

    // -----------------------------------------------------------------
    // Dropped-corner horizontal triangle: the cooked runtime triangle
    // must draw the same physical world-space triangle the editor 3D
    // preview draws. Anything else means a stair-relief / wall-frieze
    // face renders in the editor but vanishes in the streamed runtime.
    // -----------------------------------------------------------------

    /// Editor-preview corner -> world XZ for a unit cell `[0, S] x [0, S]`.
    /// Mirrors `editor_preview/room_geometry.rs::horizontal_corner_world_point`
    /// (`NW=(x0,z1), NE=(x1,z1), SE=(x1,z0), SW=(x0,z0)`).
    fn editor_corner_xz(corner: Corner, s: i32) -> (i32, i32) {
        match corner {
            Corner::NW => (0, s),
            Corner::NE => (s, s),
            Corner::SE => (s, 0),
            Corner::SW => (0, 0),
        }
    }

    /// Runtime quad-index -> world XZ for a unit cell. Mirrors
    /// `engine/.../world_render.rs::horizontal_vertices`
    /// (`0=(x0,z0), 1=(x1,z0), 2=(x1,z1), 3=(x0,z1)`).
    fn runtime_index_xz(index: usize, s: i32) -> (i32, i32) {
        match index {
            0 => (0, 0),
            1 => (s, 0),
            2 => (s, s),
            _ => (0, s),
        }
    }

    /// Signed area of the triangle projected onto the XZ plane, in the
    /// vertex order given. A top-down camera's screen-space signed area
    /// (the value the Front/Back backface test keys on, both in the
    /// editor preview `face_side_visible` and the runtime
    /// `screen_triangle_back_facing`) has the same sign as this, so two
    /// emit orders with opposite signs cull on opposite sides.
    fn signed_area_xz(pts: &[(i32, i32, i32); 3]) -> i64 {
        let (ax, _, az) = pts[0];
        let (bx, _, bz) = pts[1];
        let (cx, _, cz) = pts[2];
        let abx = (bx - ax) as i64;
        let abz = (bz - az) as i64;
        let acx = (cx - ax) as i64;
        let acz = (cz - az) as i64;
        abx * acz - abz * acx
    }

    /// Editor-preview survivor in the EXACT vertex order the preview
    /// emits it (`push_horizontal_face`): the editor triangle not
    /// containing `dropped_corner`, in `horizontal_triangle_corners`
    /// order, with the floor/ceiling winding flip applied
    /// (`flip_winding=true` for ceilings keeps `[0,1,2]`; floors use
    /// `[0,2,1]`).
    fn editor_survivor_emit_order(
        face: &GridHorizontalFace,
        dropped: Corner,
        is_ceiling: bool,
        s: i32,
    ) -> Option<[(i32, i32, i32); 3]> {
        for editor_index in 0..2 {
            let corners = crate::horizontal_triangle_corners(face.split, editor_index);
            if corners.contains(&dropped) {
                continue;
            }
            let heights = face.triangle_heights(editor_index);
            let v: Vec<(i32, i32, i32)> = corners
                .iter()
                .zip(heights)
                .map(|(corner, y)| {
                    let (x, z) = editor_corner_xz(*corner, s);
                    (x, y, z)
                })
                .collect();
            // floors reverse to `[0, 2, 1]`, ceilings keep `[0, 1, 2]`.
            return Some(if is_ceiling {
                [v[0], v[1], v[2]]
            } else {
                [v[0], v[2], v[1]]
            });
        }
        None
    }

    /// Editor-preview survivor: the editor triangle that does NOT
    /// contain `dropped_corner`, projected to sorted world `(x, y, z)`.
    /// Mirrors `push_horizontal_face`'s skip-the-dropped-half logic.
    fn editor_survivor_world(
        face: &GridHorizontalFace,
        dropped: Corner,
        s: i32,
    ) -> Option<Vec<(i32, i32, i32)>> {
        for editor_index in 0..2 {
            let corners = crate::horizontal_triangle_corners(face.split, editor_index);
            if corners.contains(&dropped) {
                continue;
            }
            let heights = face.triangle_heights(editor_index);
            let mut pts: Vec<(i32, i32, i32)> = corners
                .iter()
                .zip(heights)
                .map(|(corner, y)| {
                    let (x, z) = editor_corner_xz(*corner, s);
                    (x, y, z)
                })
                .collect();
            pts.sort();
            return Some(pts);
        }
        None
    }

    /// Runtime survivor: decode the cooked `.psxw`, find the present
    /// floor/ceiling triangle, and reconstruct its world `(x, y, z)`
    /// corners exactly as the runtime renderer does
    /// (`triangle_heights_to_quad` + `horizontal_vertices`).
    fn runtime_survivor_world(bytes: &[u8], is_ceiling: bool, s: i32) -> Vec<(i32, i32, i32)> {
        let parsed = psx_asset::World::from_bytes(bytes).expect("psxw parses");
        let sector = parsed.sector(0, 0).expect("sector 0,0 present");
        let (split, quad_heights) = if is_ceiling {
            (sector.ceiling_split(), sector.ceiling_heights())
        } else {
            (sector.floor_split(), sector.floor_heights())
        };
        let mut found: Vec<Vec<(i32, i32, i32)>> = Vec::new();
        for index in 0..2 {
            let present = if is_ceiling {
                sector.ceiling_triangle_present(index)
            } else {
                sector.floor_triangle_present(index)
            };
            if !present {
                continue;
            }
            let tri_heights = if is_ceiling {
                sector.ceiling_triangle_heights(index)
            } else {
                sector.floor_triangle_heights(index)
            };
            // Runtime split -> the three quad-corner indices for this
            // triangle, matching `split_triangles_runtime`.
            let runtime_split = if split == psxed_format::world::split::NORTH_EAST_SOUTH_WEST {
                GridSplit::NorthEastSouthWest
            } else {
                GridSplit::NorthWestSouthEast
            };
            let runtime_corners = crate::horizontal_triangle_corners(runtime_split, index);
            // `triangle_heights_to_quad`: stamp the triangle heights
            // into the quad slots, then read each corner's world point.
            let mut quad = quad_heights;
            quad[runtime_corners[0].idx()] = tri_heights[0];
            quad[runtime_corners[1].idx()] = tri_heights[1];
            quad[runtime_corners[2].idx()] = tri_heights[2];
            let mut pts: Vec<(i32, i32, i32)> = runtime_corners
                .iter()
                .map(|corner| {
                    let i = corner.idx();
                    let (x, z) = runtime_index_xz(i, s);
                    (x, quad[i], z)
                })
                .collect();
            pts.sort();
            found.push(pts);
        }
        assert_eq!(
            found.len(),
            1,
            "exactly one runtime triangle must be present for a dropped-corner face"
        );
        found.into_iter().next().unwrap()
    }

    /// Runtime survivor in the EXACT vertex order the runtime renderer
    /// emits it. Mirrors `world_render.rs::submit_split_triangle`:
    /// `tri = split_triangles_runtime(split)[index]`, then for a
    /// single-sided (`Front`) material the ceiling pass reverses to
    /// `(a, c, b)` (`reverse_front ^ (sidedness == Back)`). The
    /// quad-corner -> world point is `horizontal_vertices`.
    fn runtime_survivor_emit_order(bytes: &[u8], is_ceiling: bool, s: i32) -> [(i32, i32, i32); 3] {
        let parsed = psx_asset::World::from_bytes(bytes).expect("psxw parses");
        let sector = parsed.sector(0, 0).expect("sector 0,0 present");
        let (split, quad_heights) = if is_ceiling {
            (sector.ceiling_split(), sector.ceiling_heights())
        } else {
            (sector.floor_split(), sector.floor_heights())
        };
        let runtime_split = if split == psxed_format::world::split::NORTH_EAST_SOUTH_WEST {
            GridSplit::NorthEastSouthWest
        } else {
            GridSplit::NorthWestSouthEast
        };
        for index in 0..2 {
            let present = if is_ceiling {
                sector.ceiling_triangle_present(index)
            } else {
                sector.floor_triangle_present(index)
            };
            if !present {
                continue;
            }
            let tri_heights = if is_ceiling {
                sector.ceiling_triangle_heights(index)
            } else {
                sector.floor_triangle_heights(index)
            };
            let runtime_corners = crate::horizontal_triangle_corners(runtime_split, index);
            let mut quad = quad_heights;
            quad[runtime_corners[0].idx()] = tri_heights[0];
            quad[runtime_corners[1].idx()] = tri_heights[1];
            quad[runtime_corners[2].idx()] = tri_heights[2];
            // The three quad-corner indices for this triangle, in the
            // same order `split_triangles_runtime` produces.
            let mut order = [
                runtime_corners[0].idx(),
                runtime_corners[1].idx(),
                runtime_corners[2].idx(),
            ];
            // `reverse_front` (ceiling) with a non-Back material swaps
            // the last two vertices.
            if is_ceiling {
                order.swap(1, 2);
            }
            return [
                {
                    let (x, z) = runtime_index_xz(order[0], s);
                    (x, quad[order[0]], z)
                },
                {
                    let (x, z) = runtime_index_xz(order[1], s);
                    (x, quad[order[1]], z)
                },
                {
                    let (x, z) = runtime_index_xz(order[2], s);
                    (x, quad[order[2]], z)
                },
            ];
        }
        panic!("no present runtime triangle for dropped-corner face");
    }

    fn build_dropped_corner_face(
        material: ResourceId,
        split: GridSplit,
        dropped: Corner,
        heights: [i32; 4],
    ) -> GridHorizontalFace {
        let mut face = GridHorizontalFace::flat(0, Some(material));
        face.heights = heights;
        face.split = split;
        face.dropped_corner = Some(dropped);
        face
    }

    #[test]
    fn dropped_corner_horizontal_runtime_matches_editor_preview() {
        let (project, material) = minimal_material_project();
        let s = world::SECTOR_SIZE;
        // Distinct per-corner heights so a wrong corner/height mapping
        // cannot accidentally pass. Order is `[NW, NE, SE, SW]`.
        let heights = [7616, 8896, 4096, 1024];

        let mut failures: Vec<String> = Vec::new();
        let mut tested = 0;

        for split in [GridSplit::NorthWestSouthEast, GridSplit::NorthEastSouthWest] {
            for dropped in [Corner::NW, Corner::NE, Corner::SE, Corner::SW] {
                for is_ceiling in [false, true] {
                    let face = build_dropped_corner_face(material, split, dropped, heights);

                    let editor = editor_survivor_world(&face, dropped, s);

                    let mut grid = WorldGrid::empty(1, 1, s);
                    grid.set_floor(0, 0, 0, Some(material));
                    if is_ceiling {
                        if let Some(sector) = grid.sector_mut(0, 0) {
                            sector.ceiling = Some(face.clone());
                        }
                    } else if let Some(sector) = grid.sector_mut(0, 0) {
                        sector.floor = Some(face.clone());
                    }

                    let bytes = encode_world_grid_psxw(&project, &grid).unwrap();

                    let label = format!("{split:?} + drop {dropped:?} + ceiling={is_ceiling}");

                    match editor {
                        None => {
                            // Dropped corner lies on this split's diagonal:
                            // the editor draws nothing, so must the runtime.
                            let parsed = psx_asset::World::from_bytes(&bytes).unwrap();
                            let present = match parsed.sector(0, 0) {
                                None => false,
                                Some(sector) if is_ceiling => {
                                    sector.ceiling_triangle_present(0)
                                        || sector.ceiling_triangle_present(1)
                                }
                                Some(sector) => {
                                    sector.floor_triangle_present(0)
                                        || sector.floor_triangle_present(1)
                                }
                            };
                            if present {
                                failures.push(format!(
                                    "{label}: editor draws nothing (dropped corner on diagonal) \
                                     but runtime emits a triangle"
                                ));
                            }
                        }
                        Some(editor_pts) => {
                            tested += 1;
                            // 1) Same physical triangle (corner set).
                            let runtime_pts = runtime_survivor_world(&bytes, is_ceiling, s);
                            if runtime_pts != editor_pts {
                                failures.push(format!(
                                    "{label}: editor survivor {editor_pts:?} != runtime survivor \
                                     {runtime_pts:?}"
                                ));
                            }
                            // 2) Same emit winding. A single-sided
                            // (Front) face is backface-culled by both the
                            // editor preview and the runtime via the
                            // SIGN of the projected (XZ) signed area; if
                            // the two pipelines emit opposite winding the
                            // surface shows in the editor but vanishes in
                            // the streamed runtime.
                            let editor_emit =
                                editor_survivor_emit_order(&face, dropped, is_ceiling, s)
                                    .expect("editor survivor exists");
                            let runtime_emit = runtime_survivor_emit_order(&bytes, is_ceiling, s);
                            let editor_sign = signed_area_xz(&editor_emit).signum();
                            let runtime_sign = signed_area_xz(&runtime_emit).signum();
                            if editor_sign != runtime_sign {
                                failures.push(format!(
                                    "{label}: winding mismatch (single-sided face culls on \
                                     opposite sides) -- editor emit {editor_emit:?} (area sign \
                                     {editor_sign}) vs runtime emit {runtime_emit:?} (area sign \
                                     {runtime_sign})"
                                ));
                            }
                        }
                    }
                }
            }
        }

        assert!(
            tested >= 8,
            "expected at least 8 non-degenerate combos, tested {tested}"
        );
        assert!(
            failures.is_empty(),
            "dropped-corner runtime/editor mismatches:\n{}",
            failures.join("\n")
        );
    }
}
