//! `showcase-model` -- animated-model demo with model + clip cycling.
//!
//! Loads two cooked models that share the same Meshy biped rig, plus
//! every cooked `.psxanim` clip for each. The camera spherically
//! orbits the active model; D-pad rotates, Triangle/Cross dolly, and
//! Square/Circle step through the active model's clip set. Select
//! swaps between the two characters -- texture is re-uploaded into
//! the same VRAM slot, animation phase resets so the new clip starts
//! cleanly. An overlay draws the active model name, the current clip
//! name, and a one-line control reminder.

#![no_std]
#![no_main]
#![allow(static_mut_refs)]

extern crate psx_rt;

use psx_asset::{Animation, Model, ModelPart, ModelVertex, Texture};
use psx_engine::{
    button, Angle, App, Config, Ctx, CullMode, DepthBand, DepthPolicy, DepthRange,
    JointViewTransform, LocalToWorldScale, Mat3I16, ModelPoseTranslation, OtDepth, OtFrame,
    PrimitiveArena, ProjectedVertex, Scene, SimTick, TexturedModelGeometry, TexturedModelRenderFace,
    WorldCamera, WorldProjection, WorldRenderPass, WorldSurfaceOptions, WorldTriCommand,
    WorldVertex,
};
use psx_font::{fonts::BASIC, FontAtlas};
use psx_gpu::{material::TextureMaterial, ot::OrderingTable, prim::TriTextured};
use psx_vram::{upload_bytes, Clut, TexDepth, Tpage, VramRect};

struct ClipEntry {
    label: &'static str,
    blob: &'static [u8],
}

struct ModelEntry {
    label: &'static str,
    model: &'static [u8],
    texture: &'static [u8],
    clips: &'static [ClipEntry],
}

/// Both models share the Meshy biped rig (24 joints, identical
/// hierarchy and bind pose), so a single cooked clip set animates
/// either character. We cook the eight clips off the obsidian glb
/// because that's the drop with the full move list -- the hooded
/// wretch glb only ships running and walking.
///
/// The source export's animation names are offset from the actual
/// tracks. Labels here describe the observed motion, not the original
/// filename suffix.
const SHARED_CLIPS: &[ClipEntry] = &[
    ClipEntry {
        label: "dead",
        blob: include_bytes!(
            "../../../../assets/models/obsidian_wraith/obsidian_wraith_walk_backward_inplace.psxanim"
        ),
    },
    ClipEntry {
        label: "double_combo_attack",
        blob: include_bytes!(
            "../../../../assets/models/obsidian_wraith/obsidian_wraith_walking.psxanim"
        ),
    },
    ClipEntry {
        label: "hit_reaction",
        blob: include_bytes!(
            "../../../../assets/models/obsidian_wraith/obsidian_wraith_dead.psxanim"
        ),
    },
    ClipEntry {
        label: "idle",
        blob: include_bytes!(
            "../../../../assets/models/obsidian_wraith/obsidian_wraith_double_combo_attack.psxanim"
        ),
    },
    ClipEntry {
        label: "running",
        blob: include_bytes!(
            "../../../../assets/models/obsidian_wraith/obsidian_wraith_hit_reaction.psxanim"
        ),
    },
    ClipEntry {
        label: "unsteady_walk",
        blob: include_bytes!(
            "../../../../assets/models/obsidian_wraith/obsidian_wraith_idle.psxanim"
        ),
    },
    ClipEntry {
        label: "walk_backward_inplace",
        blob: include_bytes!(
            "../../../../assets/models/obsidian_wraith/obsidian_wraith_running.psxanim"
        ),
    },
    ClipEntry {
        label: "walking",
        blob: include_bytes!(
            "../../../../assets/models/obsidian_wraith/obsidian_wraith_unsteady_walk.psxanim"
        ),
    },
];

const MODELS: &[ModelEntry] = &[
    ModelEntry {
        label: "Obsidian Wraith",
        model: include_bytes!("../../../../assets/models/obsidian_wraith/obsidian_wraith.psxmdl"),
        texture: include_bytes!(
            "../../../../assets/models/obsidian_wraith/obsidian_wraith_128x128_8bpp.psxt"
        ),
        clips: SHARED_CLIPS,
    },
    ModelEntry {
        label: "Hooded Wretch",
        model: include_bytes!("../../../../assets/models/hooded_wretch/hooded_wretch.psxmdl"),
        texture: include_bytes!(
            "../../../../assets/models/hooded_wretch/hooded_wretch_128x128_8bpp.psxt"
        ),
        clips: SHARED_CLIPS,
    },
];

const MAX_CLIPS: usize = 8;
const SHOWCASE_START_CLIP: usize = 3;

const SCREEN_CX: i32 = 160;
const SCREEN_CY: i32 = 118;
const PROJ_FOCAL: i32 = 320;
const NEAR_Z: i32 = 48;
const PROJECTION: WorldProjection =
    WorldProjection::new(SCREEN_CX as i16, SCREEN_CY as i16, PROJ_FOCAL, NEAR_Z);

const OT_DEPTH: usize = 128;
const WORLD_BAND: DepthBand = OtDepth::<OT_DEPTH>::band(0, OT_DEPTH - 2);

/// Model texture lives in a dedicated 8bpp page well clear of the
/// font atlas at x=320. Re-upload happens on every model swap.
const TEX_TPAGE: Tpage = Tpage::new(640, 0, TexDepth::Bit8);
const TEX_CLUT: Clut = Clut::new(0, 482);

/// 4bpp 8x8 BIOS-style font atlas. Sits at x=320 (multiple of 64),
/// clear of both display buffers and the model's 8bpp page at 640.
const FONT_TPAGE: Tpage = Tpage::new(320, 0, TexDepth::Bit4);
const FONT_CLUT: Clut = Clut::new(320, 256);

const MODEL_WORLD_HEIGHT: i32 = 1024;
const MODEL_Y_OFFSET: i32 = MODEL_WORLD_HEIGHT / 2;
const MODEL_TARGET_Y: i32 = MODEL_WORLD_HEIGHT / 2;
const CAMERA_TARGET: WorldVertex = WorldVertex::new(0, MODEL_TARGET_Y, 0);
const CAMERA_RADIUS_START: i32 = 2048;
const CAMERA_RADIUS_MIN: i32 = 1152;
const CAMERA_RADIUS_MAX: i32 = 4096;
const CAMERA_RADIUS_STEP: i32 = 128;
const CAMERA_YAW_STEP_PER_VBLANK_Q12: i16 = 32;
const CAMERA_PITCH_STEP_PER_VBLANK_Q12: i16 = 24;
const CAMERA_PITCH_START: Angle = Angle::from_q12(350);
const WORLD_DEPTH_RANGE: DepthRange =
    DepthRange::new(NEAR_Z, CAMERA_RADIUS_MAX + MODEL_WORLD_HEIGHT * 2);

const TRI_CAP: usize = 1536;
const MODEL_VERTEX_CAP: usize = 1024;
const MODEL_FACE_CAP: usize = 2048;
const MODEL_PART_CAP: usize = 128;
const MODEL_SOURCE_VERTEX_CAP: usize = MODEL_VERTEX_CAP;
const JOINT_CAP: usize = 32;

static mut OT: OrderingTable<OT_DEPTH> = OrderingTable::new();
static mut TEXTURED_TRIS: [TriTextured; TRI_CAP] = [const {
    TriTextured::new(
        [(0, 0), (0, 0), (0, 0)],
        [(0, 0), (0, 0), (0, 0)],
        0,
        0,
        (0, 0, 0),
    )
}; TRI_CAP];
static mut WORLD_COMMANDS: [WorldTriCommand; TRI_CAP] = [WorldTriCommand::EMPTY; TRI_CAP];
static mut MODEL_VERTICES: [ProjectedVertex; MODEL_VERTEX_CAP] =
    [ProjectedVertex::new(0, 0, 0); MODEL_VERTEX_CAP];
static mut MODEL_RENDER_FACES: [TexturedModelRenderFace; MODEL_FACE_CAP] =
    [TexturedModelRenderFace::ZERO; MODEL_FACE_CAP];
static mut MODEL_RENDER_PARTS: [ModelPart; MODEL_PART_CAP] = [ModelPart::ZERO; MODEL_PART_CAP];
static mut MODEL_RENDER_SOURCE_VERTICES: [ModelVertex; MODEL_SOURCE_VERTEX_CAP] =
    [ModelVertex::ZERO; MODEL_SOURCE_VERTEX_CAP];
static mut JOINT_VIEW_TRANSFORMS: [JointViewTransform; JOINT_CAP] =
    [const { JointViewTransform::ZERO }; JOINT_CAP];

struct ModelShowcase {
    current_model: usize,
    current_clip: usize,
    model: Option<Model<'static>>,
    animations: [Option<Animation<'static>>; MAX_CLIPS],
    clip_origin_tick: SimTick,
    camera_yaw: Angle,
    camera_pitch: Angle,
    camera_radius: i32,
    font: Option<FontAtlas>,
}

impl Scene for ModelShowcase {
    fn init(&mut self, _ctx: &mut Ctx) {
        self.font = Some(FontAtlas::upload(&BASIC, FONT_TPAGE, FONT_CLUT));
        self.activate_model(0, SimTick::ZERO);
    }

    fn update(&mut self, ctx: &mut Ctx) {
        if ctx.just_pressed(button::SELECT) {
            let next = (self.current_model + 1) % MODELS.len();
            self.activate_model(next, ctx.sim_tick);
        }

        let entry = &MODELS[self.current_model];
        if ctx.just_pressed(button::CIRCLE) || ctx.just_pressed(button::R1) {
            self.advance_clip(ctx, 1);
        }
        if ctx.just_pressed(button::SQUARE) || ctx.just_pressed(button::L1) {
            self.advance_clip(ctx, entry.clips.len().saturating_sub(1));
        }

        let dt = 1u16;
        if ctx.is_held(button::LEFT) {
            self.camera_yaw = self
                .camera_yaw
                .add_signed_q12(-scale_i16(CAMERA_YAW_STEP_PER_VBLANK_Q12, dt));
        }
        if ctx.is_held(button::RIGHT) {
            self.camera_yaw = self
                .camera_yaw
                .add_signed_q12(scale_i16(CAMERA_YAW_STEP_PER_VBLANK_Q12, dt));
        }
        if ctx.is_held(button::UP) {
            self.camera_pitch = self
                .camera_pitch
                .add_signed_q12(scale_i16(CAMERA_PITCH_STEP_PER_VBLANK_Q12, dt));
        }
        if ctx.is_held(button::DOWN) {
            self.camera_pitch = self
                .camera_pitch
                .add_signed_q12(-scale_i16(CAMERA_PITCH_STEP_PER_VBLANK_Q12, dt));
        }
        if ctx.is_held(button::TRIANGLE) {
            self.camera_radius =
                (self.camera_radius - scale_i32(CAMERA_RADIUS_STEP, dt)).max(CAMERA_RADIUS_MIN);
        }
        if ctx.is_held(button::CROSS) {
            self.camera_radius =
                (self.camera_radius + scale_i32(CAMERA_RADIUS_STEP, dt)).min(CAMERA_RADIUS_MAX);
        }
    }

    fn render(&mut self, ctx: &mut Ctx) {
        let entry = &MODELS[self.current_model];
        if let (Some(model), Some(animation)) = (self.model, self.animations[self.current_clip]) {
            let material = TextureMaterial::opaque(
                TEX_CLUT.uv_clut_word(),
                TEX_TPAGE.uv_tpage_word(0),
                (0x80, 0x80, 0x80),
            )
            .with_raw_texture(true);
            let camera = WorldCamera::orbit(
                PROJECTION,
                CAMERA_TARGET,
                self.camera_radius,
                self.camera_yaw,
                self.camera_pitch,
            );

            let clip_tick = ctx.sim_tick.wrapping_sub(self.clip_origin_tick);
            let frame_q12 = animation.phase_at_tick_q12(clip_tick, ctx.video_hz.as_u16());
            let mut ot = unsafe { OtFrame::begin(&mut OT) };
            let mut triangles = unsafe { PrimitiveArena::new(&mut TEXTURED_TRIS) };
            let mut world = unsafe { WorldRenderPass::new(&mut ot, &mut WORLD_COMMANDS) };
            draw_animated_model(
                model,
                animation,
                frame_q12,
                camera,
                material,
                &mut world,
                &mut triangles,
            );
            world.flush();
            ot.submit();
        }

        if let Some(font) = self.font.as_ref() {
            draw_overlay(font, entry, self.current_clip);
        }
    }
}

#[no_mangle]
fn main() -> ! {
    let mut scene = ModelShowcase::new();
    let config = Config {
        clear_color: (5, 6, 10),
        ..Config::default()
    };
    App::run(config, &mut scene);
}

impl ModelShowcase {
    const fn new() -> Self {
        Self {
            current_model: 0,
            current_clip: 0,
            model: None,
            animations: [const { None }; MAX_CLIPS],
            clip_origin_tick: SimTick::ZERO,
            camera_yaw: Angle::ZERO,
            camera_pitch: CAMERA_PITCH_START,
            camera_radius: CAMERA_RADIUS_START,
            font: None,
        }
    }

    /// Swap to the model at `index`. Re-parses model, re-uploads
    /// texture into the shared VRAM slot, re-parses every clip, and
    /// resets clip phase to `now_tick` so the new clip starts at
    /// frame 0.
    fn activate_model(&mut self, index: usize, now_tick: SimTick) {
        self.current_model = index;
        let entry = &MODELS[index];
        self.current_clip = SHOWCASE_START_CLIP.min(entry.clips.len().saturating_sub(1));
        self.clip_origin_tick = now_tick;
        self.model = Some(Model::from_bytes(entry.model).expect(entry.label));
        upload_model_texture(entry.texture);
        for slot in self.animations.iter_mut() {
            *slot = None;
        }
        for (i, clip) in entry.clips.iter().enumerate() {
            if i >= MAX_CLIPS {
                break;
            }
            self.animations[i] = Some(Animation::from_bytes(clip.blob).expect(clip.label));
        }
    }

    fn advance_clip(&mut self, ctx: &Ctx, step: usize) {
        let count = MODELS[self.current_model].clips.len().max(1);
        self.current_clip = (self.current_clip + step) % count;
        self.clip_origin_tick = ctx.sim_tick;
    }
}

fn scale_i16(value: i16, scale: u16) -> i16 {
    let scaled = (value as i32).saturating_mul(scale as i32);
    scaled.clamp(i16::MIN as i32, i16::MAX as i32) as i16
}

fn scale_i32(value: i32, scale: u16) -> i32 {
    value.saturating_mul(scale as i32)
}

fn upload_model_texture(blob: &[u8]) {
    let texture = Texture::from_bytes(blob).expect("model texture");
    upload_bytes(
        VramRect::new(
            TEX_TPAGE.x(),
            TEX_TPAGE.y(),
            texture.halfwords_per_row(),
            texture.height(),
        ),
        texture.pixel_bytes(),
    );
    upload_opaque_clut(
        VramRect::new(TEX_CLUT.x(), TEX_CLUT.y(), texture.clut_entries(), 1),
        texture.clut_bytes(),
    );
}

fn upload_opaque_clut(rect: VramRect, bytes: &[u8]) {
    let mut marked = [0u8; 512];
    assert!(bytes.len() <= marked.len());
    assert!(bytes.len() % 2 == 0);

    let mut i = 0;
    while i < bytes.len() {
        let mut color = u16::from_le_bytes([bytes[i], bytes[i + 1]]);
        if color == 0 {
            color = 1;
        }
        marked[i..i + 2].copy_from_slice(&color.to_le_bytes());
        i += 2;
    }
    upload_bytes(rect, &marked[..bytes.len()]);
}

fn draw_animated_model(
    model: Model<'_>,
    animation: Animation<'_>,
    frame_q12: u32,
    camera: WorldCamera,
    material: TextureMaterial,
    world: &mut WorldRenderPass<'_, '_, OT_DEPTH>,
    triangles: &mut PrimitiveArena<'_, TriTextured>,
) {
    let options = WorldSurfaceOptions::new(WORLD_BAND, WORLD_DEPTH_RANGE)
        .with_depth_policy(DepthPolicy::Average)
        .with_cull_mode(CullMode::Back)
        .with_material_layer(material);
    let Some((geometry, faces)) = (unsafe {
        decode_model_geometry_faces(
            model,
            &mut MODEL_RENDER_FACES,
            &mut MODEL_RENDER_PARTS,
            &mut MODEL_RENDER_SOURCE_VERTICES,
        )
    }) else {
        return;
    };
    let stats = world.submit_textured_model_predecoded_geometry_faces(
        triangles,
        model,
        animation,
        frame_q12,
        camera,
        WorldVertex::new(0, MODEL_Y_OFFSET, 0),
        Mat3I16::IDENTITY,
        LocalToWorldScale::from_q12(model.local_to_world_q12()),
        ModelPoseTranslation::ZERO,
        unsafe { &mut MODEL_VERTICES },
        unsafe { &mut JOINT_VIEW_TRANSFORMS },
        material,
        options,
        faces,
        geometry,
    );
    if stats.primitive_overflow || stats.command_overflow || stats.vertex_overflow {
        return;
    }
}

fn decode_model_geometry_faces<'a>(
    model: Model<'_>,
    face_pool: &'a mut [TexturedModelRenderFace],
    part_pool: &'a mut [ModelPart],
    vertex_pool: &'a mut [ModelVertex],
) -> Option<(TexturedModelGeometry<'a>, &'a [TexturedModelRenderFace])> {
    let part_count = model.part_count() as usize;
    let vertex_count = model.vertex_count() as usize;
    let face_count = model.face_count() as usize;
    if part_pool.len() < part_count
        || vertex_pool.len() < vertex_count
        || face_pool.len() < face_count
    {
        return None;
    }

    let mut i = 0usize;
    while i < part_count {
        part_pool[i] = model.part(i as u16)?;
        i += 1;
    }
    i = 0;
    while i < vertex_count {
        vertex_pool[i] = model.vertex(i as u16)?;
        i += 1;
    }

    let (max_u, max_v) = model_texture_uv_limits(model);
    i = 0;
    while i < face_count {
        let face = model.face(i as u16)?;
        face_pool[i] = TexturedModelRenderFace::new(
            [
                face.corners[0].vertex_index,
                face.corners[1].vertex_index,
                face.corners[2].vertex_index,
            ],
            [
                clamp_model_uv(face.corners[0].uv, max_u, max_v),
                clamp_model_uv(face.corners[1].uv, max_u, max_v),
                clamp_model_uv(face.corners[2].uv, max_u, max_v),
            ],
        );
        i += 1;
    }

    Some((
        TexturedModelGeometry::new(&part_pool[..part_count], &vertex_pool[..vertex_count]),
        &face_pool[..face_count],
    ))
}

fn model_texture_uv_limits(model: Model<'_>) -> (u8, u8) {
    (
        model_texture_uv_max(model.texture_width()),
        model_texture_uv_max(model.texture_height()),
    )
}

fn model_texture_uv_max(size: u16) -> u8 {
    size.saturating_sub(1).min(u16::from(u8::MAX)) as u8
}

fn clamp_model_uv(uv: (u8, u8), max_u: u8, max_v: u8) -> (u8, u8) {
    (uv.0.min(max_u), uv.1.min(max_v))
}

/// One-frame text overlay: model name + clip name at the top, control
/// reminder at the bottom. Drawn after the 3D scene so it sits over
/// the model without participating in the OT.
fn draw_overlay(font: &FontAtlas, entry: &ModelEntry, current_clip: usize) {
    font.draw_text(8, 8, entry.label, (235, 235, 245));

    let clip_label = entry
        .clips
        .get(current_clip)
        .map(|c| c.label)
        .unwrap_or("-");
    font.draw_text(8, 20, clip_label, (160, 220, 160));

    font.draw_text(8, 216, "DPAD orbit  TRI/X zoom", (180, 180, 200));
    font.draw_text(8, 226, "SQ/O clip  SEL model", (180, 180, 200));
}
