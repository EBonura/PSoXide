// Axis-aligned textured quad with bilinear UV interpolation.
//
// Mirrors `emulator-core::Gpu::rasterize_axis_aligned_textured_quad`
// byte-for-byte: per-row left/right UV walk in Q12 with a +0.5
// seed, then per-pixel linear interpolation between them. The CPU dispatches this fast
// path when a textured quad's vertices form an axis-aligned
// rectangle; for non-affine UV layouts the bilinear math here
// produces different pixels than triangle-split barycentric.
//
// Layout assumption (matches CPU): v0/v2 share one vertical edge,
// v1/v3 share the other, but either edge may be left/right and either
// row may be top/bottom. UVs follow the submitted vertex order.
//
// i64 emulation helpers identical to the scanline shaders - see
// `tex_tri_scanline.wgsl` for explanation.

struct TexQuadBilinear {
    v0: vec2<i32>,
    v1: vec2<i32>,
    v2: vec2<i32>,
    v3: vec2<i32>,
    uv0: u32, uv1: u32, uv2: u32, uv3: u32,
    clut_x: u32,
    clut_y: u32,
    tint: u32,
    flags: u32,
}

struct Tpage {
    tpage_x: u32, tpage_y: u32, tex_depth: u32, _pad: u32,
    tex_window_mask_x: u32, tex_window_mask_y: u32,
    tex_window_off_x: u32, tex_window_off_y: u32,
}

struct DrawArea { left: i32, top: i32, right: i32, bottom: i32 }

@group(0) @binding(0) var<storage, read_write> vram: array<u32>;
@group(0) @binding(1) var<uniform> prim: TexQuadBilinear;
@group(0) @binding(2) var<uniform> draw_area: DrawArea;
@group(0) @binding(3) var<uniform> tpage: Tpage;

struct I64 { hi: i32, lo: u32 }
fn i64_pack(hi: i32, lo: u32) -> I64 { return I64(hi, lo); }

fn i64_add(a: I64, b: I64) -> I64 {
    let new_lo = a.lo + b.lo;
    let carry: i32 = select(0, 1, new_lo < a.lo);
    return I64(a.hi + b.hi + carry, new_lo);
}

fn i64_sub(a: I64, b: I64) -> I64 {
    // a - b == a + (-b). Two's complement: -b = ~b + 1.
    let neg_lo = (~b.lo) + 1u;
    // If b.lo was 0, ~b.lo + 1 wraps to 0 (no carry); else there's a
    // borrow into the high half. Equivalently: borrow = 1 iff b.lo != 0.
    let neg_hi = (~b.hi) + select(0, 1, b.lo == 0u);
    return i64_add(a, I64(neg_hi, neg_lo));
}

fn i64_mul_u32(col: u32, b: I64) -> I64 {
    let bL = b.lo & 0xFFFFu;
    let bH = b.lo >> 16u;
    let pL = col * bL;
    let pH = col * bH;
    let new_lo_a = pH << 16u;
    let new_lo = new_lo_a + pL;
    let carry: u32 = select(0u, 1u, new_lo < new_lo_a);
    let high_from_lo = (pH >> 16u) + carry;
    let high_from_hi = i32(col) * b.hi;
    return I64(high_from_hi + i32(high_from_lo), new_lo);
}

// Q16.16 divide of an I64 by a positive i32 scalar. Used to compute
// per-pixel `delta_u = (right_u - pos_u) / width`. Implementation:
// long division. Width is at most 1023, so we don't need full
// 64-bit-by-32-bit precision - but we DO need it to handle negative
// numerators correctly.
fn i64_div_i32(a: I64, divisor: i32) -> I64 {
    // For PSX rasterizer outputs, `a` always fits in i32 by the
    // time it's being divided here (it's the difference of two
    // 5-bit-channel-times-Q16.16 values, whose magnitude is bounded
    // by 255 << 16 = 16M, well within i32). So we can safely
    // collapse to i32 division: for an in-range value the two's-
    // complement bits ARE `a.lo` (hi is pure sign extension, 0 or
    // -1). The old `i32(a.lo) | a.hi` collapse forced every
    // NEGATIVE numerator to -1, so reversed-UV (X-flipped sprite)
    // quads walked their texture with delta 0 instead of a negative
    // step -- alttp gameplay chunk-16 parity divergence.
    let n_i32 = i32(a.lo);
    let q = n_i32 / divisor;
    if q < 0 { return I64(-1, u32(q)); }
    return I64(0, u32(q));
}

fn i64_arsh16(a: I64) -> I64 {
    return I64(a.hi >> 16u, (a.lo >> 16u) | (u32(a.hi) << 16u));
}

fn i64_to_i32(a: I64) -> i32 { return i32(a.lo); }

fn sample_texture(u_in: u32, v_in: u32) -> u32 {
    let u8v = u_in & 0xFFu;
    let v8v = v_in & 0xFFu;
    let mx = tpage.tex_window_mask_x;
    let my = tpage.tex_window_mask_y;
    let ox = tpage.tex_window_off_x;
    let oy = tpage.tex_window_off_y;
    let uw = (u8v & ~mx) | (ox & mx);
    let vw = (v8v & ~my) | (oy & my);
    let tpy = (tpage.tpage_y + vw) & (VRAM_HEIGHT_U - 1u);
    var texel: u32 = 0u;
    switch tpage.tex_depth {
        case DEPTH_4BPP: {
            let tpx = (tpage.tpage_x + (uw >> 2u)) & (VRAM_WIDTH_U - 1u);
            let word = vram[tpy * VRAM_WIDTH_U + tpx];
            let idx = (word >> ((uw & 3u) * 4u)) & 0xFu;
            let cx = (prim.clut_x + idx) & (VRAM_WIDTH_U - 1u);
            let cy = prim.clut_y & (VRAM_HEIGHT_U - 1u);
            texel = vram[cy * VRAM_WIDTH_U + cx];
        }
        case DEPTH_8BPP: {
            let tpx = (tpage.tpage_x + (uw >> 1u)) & (VRAM_WIDTH_U - 1u);
            let word = vram[tpy * VRAM_WIDTH_U + tpx];
            let idx = (word >> ((uw & 1u) * 8u)) & 0xFFu;
            let cx = (prim.clut_x + idx) & (VRAM_WIDTH_U - 1u);
            let cy = prim.clut_y & (VRAM_HEIGHT_U - 1u);
            texel = vram[cy * VRAM_WIDTH_U + cx];
        }
        case DEPTH_15BPP, default: {
            let tpx = (tpage.tpage_x + uw) & (VRAM_WIDTH_U - 1u);
            texel = vram[tpy * VRAM_WIDTH_U + tpx];
        }
    }
    return texel;
}

@compute @workgroup_size(8, 8)
fn rasterize(@builtin(global_invocation_id) gid: vec3<u32>) {
    // Quad bbox: normalize axis-aligned quads whose submitted edge
    // order is mirrored. Tekken 3's P2 VS portrait uses v0/v2 on the
    // right edge and v1/v3 on the left edge.
    let x0 = prim.v0.x;
    let x1 = prim.v1.x;
    let y0 = prim.v0.y;
    let y1 = prim.v2.y;
    let left = min(x0, x1);
    let right = max(x0, x1);
    let top = min(y0, y1);
    let bottom = max(y0, y1);
    let width = right - left;
    let height = bottom - top;
    if width <= 0 || height <= 0 { return; }

    let dx = i32(gid.x);
    let dy = i32(gid.y);
    if dx >= width || dy >= height { return; }
    let px = left + dx;
    let py = top + dy;
    if px < draw_area.left || px > draw_area.right { return; }
    if py < draw_area.top || py > draw_area.bottom { return; }
    if px < 0 || px >= VRAM_WIDTH || py < 0 || py >= VRAM_HEIGHT { return; }

    // CPU fast-path math uses Q12 gradients and a pixel-centre seed:
    //   left_u0  = (t0.u << 12) + 0.5
    //   right_u0 = (t1.u << 12) + 0.5
    //   delta_left_u  = ((t2.u - t0.u) << 12) / height
    //   delta_right_u = ((t3.u - t1.u) << 12) / height
    //   pos_u   = left_u0 + row * delta_left_u
    //   right_u = right_u0 + row * delta_right_u
    //   delta_col_u = (right_u - pos_u) / width
    //   u = (pos_u + col * delta_col_u) >> 12
    let u0 = i32(prim.uv0 & 0xFFu);
    let vv0 = i32((prim.uv0 >> 8u) & 0xFFu);
    let u1 = i32(prim.uv1 & 0xFFu);
    let vv1 = i32((prim.uv1 >> 8u) & 0xFFu);
    let u2 = i32(prim.uv2 & 0xFFu);
    let vv2 = i32((prim.uv2 >> 8u) & 0xFFu);
    let u3 = i32(prim.uv3 & 0xFFu);
    let vv3 = i32((prim.uv3 >> 8u) & 0xFFu);

    var top_a_u: i32;
    var top_a_v: i32;
    var bottom_a_u: i32;
    var bottom_a_v: i32;
    var top_b_u: i32;
    var top_b_v: i32;
    var bottom_b_u: i32;
    var bottom_b_v: i32;
    if y0 <= y1 {
        top_a_u = u0; bottom_a_u = u2; top_b_u = u1; bottom_b_u = u3;
        top_a_v = vv0; bottom_a_v = vv2; top_b_v = vv1; bottom_b_v = vv3;
    } else {
        top_a_u = u2; bottom_a_u = u0; top_b_u = u3; bottom_b_u = u1;
        top_a_v = vv2; bottom_a_v = vv0; top_b_v = vv3; bottom_b_v = vv1;
    }

    var left_top_u: i32;
    var left_top_v: i32;
    var left_bottom_u: i32;
    var left_bottom_v: i32;
    var right_top_u: i32;
    var right_top_v: i32;
    var right_bottom_u: i32;
    var right_bottom_v: i32;
    if x0 <= x1 {
        left_top_u = top_a_u; left_bottom_u = bottom_a_u;
        left_top_v = top_a_v; left_bottom_v = bottom_a_v;
        right_top_u = top_b_u; right_bottom_u = bottom_b_u;
        right_top_v = top_b_v; right_bottom_v = bottom_b_v;
    } else {
        left_top_u = top_b_u; left_bottom_u = bottom_b_u;
        left_top_v = top_b_v; left_bottom_v = bottom_b_v;
        right_top_u = top_a_u; right_bottom_u = bottom_a_u;
        right_top_v = top_a_v; right_bottom_v = bottom_a_v;
    }

    // These bounds fit comfortably in i32: UV is 8-bit, Q12 is
    // about one million, and screen extents are at most 1023.
    let attr_shift = 12i;
    let attr_half = 1i << 11u;
    let left_u0 = (left_top_u << u32(attr_shift)) + attr_half;
    let left_v0 = (left_top_v << u32(attr_shift)) + attr_half;
    let right_u0 = (right_top_u << u32(attr_shift)) + attr_half;
    let right_v0 = (right_top_v << u32(attr_shift)) + attr_half;
    let delta_left_u = ((left_bottom_u - left_top_u) << u32(attr_shift)) / height;
    let delta_left_v = ((left_bottom_v - left_top_v) << u32(attr_shift)) / height;
    let delta_right_u = ((right_bottom_u - right_top_u) << u32(attr_shift)) / height;
    let delta_right_v = ((right_bottom_v - right_top_v) << u32(attr_shift)) / height;

    let row_u_left = left_u0 + dy * delta_left_u;
    let row_v_left = left_v0 + dy * delta_left_v;
    let row_u_right = right_u0 + dy * delta_right_u;
    let row_v_right = right_v0 + dy * delta_right_v;
    let delta_col_u = (row_u_right - row_u_left) / width;
    let delta_col_v = (row_v_right - row_v_left) / width;
    let u = u32((row_u_left + dx * delta_col_u) >> u32(attr_shift));
    let v = u32((row_v_left + dx * delta_col_v) >> u32(attr_shift));

    let texel = sample_texture(u, v);
    if texel == 0u { return; }

    var fg: u32;
    if (prim.flags & FLAG_RAW_TEXTURE) != 0u {
        fg = texel;
    } else if (prim.flags & FLAG_DITHER) != 0u && (prim.tint & 0xFFFFFFu) != 0x808080u {
        // Flat-tint textured prims dither their modulated texels when
        // GP0 0xE1 bit 9 is set -- same rule as the CPU's
        // `modulate_tint_dithered` in the axis-aligned quad path.
        // Identity tint (0x808080) matches the CPU's RAW_TEXTURE_TINT
        // sentinel and is never dithered.
        fg = modulate_dithered(
            texel,
            prim.tint & 0xFFu,
            (prim.tint >> 8u) & 0xFFu,
            (prim.tint >> 16u) & 0xFFu,
            px, py,
        );
    } else {
        fg = modulate_tint(texel, prim.tint);
    }

    let idx = u32(py * VRAM_WIDTH + px);
    let semi_trans_active =
        ((prim.flags & FLAG_SEMI_TRANS) != 0u) && ((texel & 0x8000u) != 0u);
    let needs_read = ((prim.flags & FLAG_MASK_CHECK) != 0u) || semi_trans_active;
    var existing: u32 = 0u;
    if needs_read { existing = vram[idx]; }
    if (prim.flags & FLAG_MASK_CHECK) != 0u {
        if (existing & 0x8000u) != 0u { return; }
    }
    var pixel: u32;
    if semi_trans_active {
        let mode = (prim.flags >> 8u) & 0x3u;
        pixel = blend(existing, fg, mode);
    } else {
        pixel = fg;
    }
    if (prim.flags & FLAG_MASK_SET) != 0u {
        pixel = pixel | 0x8000u;
    }
    vram[idx] = pixel;
}
